import { initializeApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, collection, doc, getDocs, addDoc, updateDoc, deleteDoc, query, where, orderBy, limit, serverTimestamp } from "firebase/firestore";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyCW2PI7Fwz92Sy35FSrRnrqiRWQjwMniOk",
  authDomain: "brawlleagues.firebaseapp.com",
  projectId: "brawlleagues",
  storageBucket: "brawlleagues.firebasestorage.app",
  messagingSenderId: "1016284202866",
  appId: "1:1016284202866:web:423e5d9218731737343feb",
  measurementId: "G-HSLGGZQLKF"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Authentication functions
export const loginWithCredentials = async (username: string, password: string) => {
  // For simplicity, we'll use email format for Firebase auth
  const email = `${username}@brawlleagues.com`;
  return await signInWithEmailAndPassword(auth, email, password);
};

export const logout = async () => {
  return await signOut(auth);
};

export const onAuthChange = (callback: (user: any) => void) => {
  return onAuthStateChanged(auth, callback);
};

// Firestore helper functions
export const addDocument = async (collectionName: string, data: any) => {
  return await addDoc(collection(db, collectionName), {
    ...data,
    createdAt: serverTimestamp(),
  });
};

export const getDocuments = async (collectionName: string, queryConstraints?: any[]) => {
  const q = queryConstraints 
    ? query(collection(db, collectionName), ...queryConstraints)
    : collection(db, collectionName);
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const updateDocument = async (collectionName: string, docId: string, data: any) => {
  return await updateDoc(doc(db, collectionName, docId), {
    ...data,
    updatedAt: serverTimestamp(),
  });
};

export const deleteDocument = async (collectionName: string, docId: string) => {
  return await deleteDoc(doc(db, collectionName, docId));
};

// Pre-configured users (these should be created in Firebase Auth)
export const PREDEFINED_USERS = {
  "joaquim.admin": { password: "S0b@2025", role: "soberano", displayName: "Joaquim" },
  "danielle.luminous": { password: "L1gHt@2025", role: "oficial", division: "luminous", displayName: "Danielle" },
  "joao.luminous": { password: "J0l!2025", role: "oficial", division: "luminous", displayName: "João" },
  "joaovinicius.valyrian": { password: "ValyR@2025", role: "oficial", division: "valyrian", displayName: "João Vinícius" },
  "kael.valyrian": { password: "KaeL@2025", role: "oficial", division: "valyrian", displayName: "Kael" },
};

// Initialize default divisions (4 divisions only)
export const DIVISIONS = [
  {
    name: "Luminous League",
    currentTrophies: 24850,
    monthlyVariation: 1250,
    activePlayers: 42,
    icon: "crown",
    color: "#FDB813"
  },
  {
    name: "Valyrian League",
    currentTrophies: 22340,
    monthlyVariation: 890,
    activePlayers: 38,
    icon: "fire",
    color: "#EF4444"
  },
  {
    name: "Shadow League",
    currentTrophies: 19720,
    monthlyVariation: -320,
    activePlayers: 35,
    icon: "mask",
    color: "#FDB813"
  },
  {
    name: "Storm League",
    currentTrophies: 21560,
    monthlyVariation: 640,
    activePlayers: 41,
    icon: "bolt",
    color: "#FDB813"
  }
];
