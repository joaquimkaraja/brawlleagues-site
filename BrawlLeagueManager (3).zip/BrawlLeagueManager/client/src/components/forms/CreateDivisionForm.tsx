import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { addDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Crown, Plus } from "lucide-react";

const divisionSchema = z.object({
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  currentTrophies: z.number().min(0, "Troféus não podem ser negativos"),
  color: z.string().min(1, "Selecione uma cor"),
  icon: z.string().min(1, "Selecione um ícone"),
});

type DivisionForm = z.infer<typeof divisionSchema>;

interface CreateDivisionFormProps {
  onSuccess: () => void;
  userRole: string;
}

const DIVISION_COLORS = [
  { value: "#FDB813", label: "Dourado" },
  { value: "#EF4444", label: "Vermelho" },
  { value: "#3B82F6", label: "Azul" },
  { value: "#10B981", label: "Verde" },
  { value: "#8B5CF6", label: "Roxo" },
  { value: "#F59E0B", label: "Laranja" },
  { value: "#EC4899", label: "Rosa" },
  { value: "#6B7280", label: "Cinza" },
];

const DIVISION_ICONS = [
  { value: "crown", label: "Coroa" },
  { value: "fire", label: "Fogo" },
  { value: "mask", label: "Máscara" },
  { value: "bolt", label: "Raio" },
  { value: "star", label: "Estrela" },
  { value: "shield", label: "Escudo" },
  { value: "sword", label: "Espada" },
  { value: "gem", label: "Gema" },
];

export function CreateDivisionForm({ onSuccess, userRole }: CreateDivisionFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<DivisionForm>({
    resolver: zodResolver(divisionSchema),
    defaultValues: {
      name: "",
      currentTrophies: 0,
      color: "",
      icon: "",
    },
  });

  const onSubmit = async (data: DivisionForm) => {
    if (userRole !== "soberano") {
      toast({
        title: "Acesso Negado",
        description: "Apenas o Soberano pode criar divisões",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await addDocument("divisions", {
        name: data.name,
        currentTrophies: data.currentTrophies,
        monthlyVariation: 0,
        activePlayers: 0,
        color: data.color,
        icon: data.icon,
      });

      // Add action history
      await addDocument("actionHistory", {
        action: "division_created",
        description: `Divisão "${data.name}" criada`,
        performedBy: userRole,
        entityType: "division",
      });

      toast({
        title: "Sucesso!",
        description: "Divisão criada com sucesso!",
      });

      form.reset();
      onSuccess();
    } catch (error) {
      console.error("Error creating division:", error);
      toast({
        title: "Erro",
        description: "Erro ao criar divisão. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (userRole !== "soberano") {
    return (
      <Card className="bg-gaming-surface border-red-500/20">
        <CardContent className="p-6 text-center">
          <div className="text-red-400 mb-2">🔒 Acesso Restrito</div>
          <p className="text-gray-400">Apenas o Soberano pode criar novas divisões</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gaming-surface border-gaming-yellow/20">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
          <Crown className="h-5 w-5 mr-2" />
          Criar Nova Divisão (Soberano)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Division Name */}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Nome da Divisão *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                        placeholder="Ex: Phoenix League"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Initial Trophies */}
              <FormField
                control={form.control}
                name="currentTrophies"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Troféus Iniciais *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        min="0"
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                        placeholder="Ex: 15000"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Color Selection */}
              <FormField
                control={form.control}
                name="color"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Cor da Divisão *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                          <SelectValue placeholder="Selecione uma cor" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-gaming-card border-gray-600">
                        {DIVISION_COLORS.map((color) => (
                          <SelectItem key={color.value} value={color.value}>
                            <div className="flex items-center space-x-2">
                              <div 
                                className="w-4 h-4 rounded-full"
                                style={{ backgroundColor: color.value }}
                              />
                              <span>{color.label}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Icon Selection */}
              <FormField
                control={form.control}
                name="icon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Ícone da Divisão *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                          <SelectValue placeholder="Selecione um ícone" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-gaming-card border-gray-600">
                        {DIVISION_ICONS.map((icon) => (
                          <SelectItem key={icon.value} value={icon.value}>
                            {icon.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Preview */}
            {form.watch("name") && form.watch("color") && (
              <div className="p-4 bg-gaming-card rounded-lg border border-gaming-yellow/20">
                <h4 className="text-white mb-2">Prévia:</h4>
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-6 h-6 rounded-full"
                    style={{ backgroundColor: form.watch("color") }}
                  />
                  <span className="text-white font-semibold">{form.watch("name")}</span>
                  <span className="text-gaming-yellow">
                    {form.watch("currentTrophies").toLocaleString()} troféus
                  </span>
                </div>
              </div>
            )}

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
            >
              {isSubmitting ? "Criando..." : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  Criar Divisão
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}