import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { getDocuments, addDocument, updateDocument, deleteDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Shield, UserPlus, Edit, Trash2, AlertTriangle, Crown } from "lucide-react";

const adminUserSchema = z.object({
  username: z.string().min(3, "Username deve ter pelo menos 3 caracteres"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  displayName: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  role: z.enum(["soberano", "oficial"], { required_error: "Selecione um cargo" }),
  division: z.string().optional(),
});

type AdminUserForm = z.infer<typeof adminUserSchema>;

interface AdminUser {
  id: string;
  username: string;
  displayName: string;
  role: string;
  division?: string;
  createdAt: any;
}

interface Division {
  id: string;
  name: string;
  color: string;
}

interface AdminUserFormProps {
  currentUserRole: string;
}

export function AdminUserForm({ currentUserRole }: AdminUserFormProps) {
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<AdminUserForm>({
    resolver: zodResolver(adminUserSchema),
    defaultValues: {
      username: "",
      password: "",
      displayName: "",
      role: "oficial",
      division: "",
    },
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [usersData, divisionsData] = await Promise.all([
        getDocuments("users"),
        getDocuments("divisions")
      ]);
      
      // Filter users to show only admin roles
      const adminUsers = usersData.filter((user: any) => 
        user.role === "soberano" || user.role === "oficial"
      );
      
      setAdminUsers(adminUsers as AdminUser[]);
      setDivisions(divisionsData as Division[]);
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: AdminUserForm) => {
    if (currentUserRole !== "soberano") {
      toast({
        title: "Acesso Negado",
        description: "Apenas o Soberano pode gerenciar administradores",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingUser) {
        // Update existing user
        await updateDocument("users", editingUser.id, {
          username: data.username,
          displayName: data.displayName,
          role: data.role,
          division: data.division || null,
          ...(data.password && { password: data.password }), // Only update password if provided
        });

        toast({
          title: "Sucesso!",
          description: "Administrador atualizado com sucesso!",
        });
      } else {
        // Create new user
        await addDocument("users", {
          username: data.username,
          password: data.password,
          displayName: data.displayName,
          role: data.role,
          division: data.division || null,
        });

        toast({
          title: "Sucesso!",
          description: "Administrador criado com sucesso!",
        });
      }

      // Add action history
      await addDocument("actionHistory", {
        action: editingUser ? "admin_updated" : "admin_created",
        description: `Administrador "${data.displayName}" ${editingUser ? "atualizado" : "criado"}`,
        performedBy: currentUserRole,
        entityType: "user",
      });

      form.reset();
      setEditingUser(null);
      setShowCreateForm(false);
      loadData();
    } catch (error) {
      console.error("Error saving admin user:", error);
      toast({
        title: "Erro",
        description: "Erro ao salvar administrador. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (user: AdminUser) => {
    setEditingUser(user);
    form.reset({
      username: user.username,
      displayName: user.displayName,
      role: user.role as "soberano" | "oficial",
      division: user.division || "",
      password: "", // Don't pre-fill password
    });
    setShowCreateForm(true);
  };

  const handleDelete = async (userId: string) => {
    if (currentUserRole !== "soberano") return;

    try {
      await deleteDocument("users", userId);

      // Add action history
      const user = adminUsers.find(u => u.id === userId);
      await addDocument("actionHistory", {
        action: "admin_deleted",
        description: `Administrador "${user?.displayName}" removido`,
        performedBy: currentUserRole,
        entityType: "user",
      });

      toast({
        title: "Sucesso!",
        description: "Administrador removido com sucesso!",
      });

      setShowDeleteConfirm(null);
      loadData();
    } catch (error) {
      console.error("Error deleting admin user:", error);
      toast({
        title: "Erro",
        description: "Erro ao remover administrador.",
        variant: "destructive",
      });
    }
  };

  const getDivisionById = (divisionId: string) => {
    return divisions.find(d => d.id === divisionId);
  };

  if (currentUserRole !== "soberano") {
    return (
      <Card className="bg-gaming-surface border-red-500/20">
        <CardContent className="p-6 text-center">
          <div className="text-red-400 mb-2">🔒 Acesso Restrito</div>
          <p className="text-gray-400">Apenas o Soberano pode gerenciar administradores</p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return <div className="text-center text-gray-400 py-8">Carregando...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header with Create Button */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Painel de Administradores (Soberano)
            </CardTitle>
            <Dialog open={showCreateForm} onOpenChange={setShowCreateForm}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber"
                  onClick={() => {
                    setEditingUser(null);
                    form.reset();
                  }}
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Criar Administrador
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gaming-surface border-gaming-yellow/20 text-white max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-gaming-yellow">
                    {editingUser ? "Editar Administrador" : "Criar Novo Administrador"}
                  </DialogTitle>
                </DialogHeader>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Nome de Usuário *</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                              placeholder="Ex: admin.user"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">
                            Senha {editingUser ? "(deixe em branco para manter atual)" : "*"}
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="password"
                              className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                              placeholder={editingUser ? "Nova senha (opcional)" : "Digite a senha"}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="displayName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Nome de Exibição *</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                              placeholder="Ex: João Silva"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Cargo *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-gaming-card border-gray-600">
                              <SelectItem value="soberano">
                                <div className="flex items-center space-x-2">
                                  <Crown className="h-4 w-4 text-gaming-yellow" />
                                  <span>Soberano</span>
                                </div>
                              </SelectItem>
                              <SelectItem value="oficial">
                                <div className="flex items-center space-x-2">
                                  <Shield className="h-4 w-4 text-blue-400" />
                                  <span>Alto Oficial</span>
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="division"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Divisão (opcional)</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                                <SelectValue placeholder="Selecione uma divisão" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-gaming-card border-gray-600">
                              {divisions.map((division) => (
                                <SelectItem key={division.id} value={division.id}>
                                  <div className="flex items-center space-x-2">
                                    <div 
                                      className="w-3 h-3 rounded-full"
                                      style={{ backgroundColor: division.color }}
                                    />
                                    <span>{division.name}</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex space-x-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowCreateForm(false)}
                        className="flex-1"
                      >
                        Cancelar
                      </Button>
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="flex-1 bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber"
                      >
                        {isSubmitting ? "Salvando..." : (editingUser ? "Atualizar" : "Criar")}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
      </Card>

      {/* Admin Users List */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-white">
            Administradores Cadastrados ({adminUsers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {adminUsers.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum administrador cadastrado
            </div>
          ) : (
            <div className="space-y-3">
              {adminUsers.map((user) => {
                const division = user.division ? getDivisionById(user.division) : null;
                
                return (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-4 bg-gaming-card rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gaming-yellow rounded-full flex items-center justify-center">
                        {user.role === "soberano" ? (
                          <Crown className="h-6 w-6 text-gaming-dark" />
                        ) : (
                          <Shield className="h-6 w-6 text-gaming-dark" />
                        )}
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{user.displayName}</h4>
                        <p className="text-sm text-gray-400">@{user.username}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge className={user.role === "soberano" ? "bg-gaming-yellow text-gaming-dark" : "bg-blue-600"}>
                            {user.role === "soberano" ? "Soberano" : "Alto Oficial"}
                          </Badge>
                          {division && (
                            <Badge 
                              style={{ backgroundColor: division.color }}
                              className="text-white text-xs"
                            >
                              {division.name}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(user)}
                        className="border-gaming-yellow text-gaming-yellow hover:bg-gaming-yellow hover:text-gaming-dark"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Dialog open={showDeleteConfirm === user.id} onOpenChange={(open) => setShowDeleteConfirm(open ? user.id : null)}>
                        <DialogTrigger asChild>
                          <Button size="sm" variant="destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-gaming-surface border-gaming-yellow/20 text-white">
                          <DialogHeader>
                            <DialogTitle className="flex items-center text-red-400">
                              <AlertTriangle className="h-5 w-5 mr-2" />
                              Confirmar Exclusão
                            </DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <p className="text-gray-300">
                              ⚠️ Tem certeza? Esta ação é irreversível e removerá permanentemente o administrador "{user.displayName}".
                            </p>
                            <div className="flex space-x-2 justify-end">
                              <Button
                                variant="outline"
                                onClick={() => setShowDeleteConfirm(null)}
                              >
                                Cancelar
                              </Button>
                              <Button
                                variant="destructive"
                                onClick={() => handleDelete(user.id)}
                              >
                                Remover Definitivamente
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}