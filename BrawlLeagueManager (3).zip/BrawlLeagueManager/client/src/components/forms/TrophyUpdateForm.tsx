import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { getDocuments, addDocument, updateDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Trophy, TrendingUp, TrendingDown, Activity } from "lucide-react";

const trophyUpdateSchema = z.object({
  divisionId: z.string().min(1, "Selecione uma divisão"),
  newTrophies: z.number().min(0, "Troféus não podem ser negativos"),
});

type TrophyUpdateForm = z.infer<typeof trophyUpdateSchema>;

interface Division {
  id: string;
  name: string;
  currentTrophies: number;
  monthlyVariation: number;
  activePlayers: number;
  color: string;
}

interface TrophyUpdateFormProps {
  userRole: string;
  onSuccess: () => void;
}

export function TrophyUpdateForm({ userRole, onSuccess }: TrophyUpdateFormProps) {
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [selectedDivision, setSelectedDivision] = useState<Division | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<TrophyUpdateForm>({
    resolver: zodResolver(trophyUpdateSchema),
    defaultValues: {
      divisionId: "",
      newTrophies: 0,
    },
  });

  useEffect(() => {
    loadDivisions();
  }, []);

  const loadDivisions = async () => {
    setIsLoading(true);
    try {
      const divisionsData = await getDocuments("divisions");
      setDivisions(divisionsData as Division[]);
    } catch (error) {
      console.error("Error loading divisions:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar divisões",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: TrophyUpdateForm) => {
    if (!selectedDivision) return;

    setIsSubmitting(true);
    try {
      const previousTrophies = selectedDivision.currentTrophies;
      const trophyDifference = data.newTrophies - previousTrophies;

      // Update division trophies and monthly variation
      await updateDocument("divisions", data.divisionId, {
        currentTrophies: data.newTrophies,
        monthlyVariation: trophyDifference,
        updatedAt: new Date(),
      });

      // Add to trophy history
      await addDocument("trophyHistory", {
        divisionId: data.divisionId,
        trophies: data.newTrophies,
      });

      // Add action history
      const action = trophyDifference > 0 ? "trophy_increase" : trophyDifference < 0 ? "trophy_decrease" : "trophy_update";
      const description = `Troféus da ${selectedDivision.name} atualizados: ${previousTrophies} → ${data.newTrophies} (${trophyDifference >= 0 ? '+' : ''}${trophyDifference})`;
      
      await addDocument("actionHistory", {
        action,
        description,
        performedBy: userRole,
        entityType: "division",
        entityId: data.divisionId,
      });

      // Create notification for significant changes
      if (Math.abs(trophyDifference) >= 500) {
        const notificationType = trophyDifference > 0 ? "success" : "warning";
        const notificationTitle = trophyDifference > 0 
          ? "🎉 Grande Crescimento!" 
          : "⚠️ Queda Significativa";
        
        await addDocument("notifications", {
          title: notificationTitle,
          message: `${selectedDivision.name}: ${trophyDifference >= 0 ? '+' : ''}${trophyDifference} troféus`,
          type: notificationType,
          priority: Math.abs(trophyDifference) >= 1000 ? "high" : "medium",
        });
      }

      toast({
        title: "Sucesso!",
        description: `Troféus da ${selectedDivision.name} atualizados com sucesso!`,
      });

      form.reset();
      setSelectedDivision(null);
      onSuccess();
      loadDivisions();
    } catch (error) {
      console.error("Error updating trophies:", error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar troféus. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDivisionSelect = (divisionId: string) => {
    const division = divisions.find(d => d.id === divisionId);
    setSelectedDivision(division || null);
    
    if (division) {
      form.setValue("newTrophies", division.currentTrophies);
    }
  };

  const calculateDifference = () => {
    if (!selectedDivision) return 0;
    const newTrophies = form.watch("newTrophies") || 0;
    return newTrophies - selectedDivision.currentTrophies;
  };

  const difference = calculateDifference();

  if (isLoading) {
    return <div className="text-center text-gray-400 py-8">Carregando...</div>;
  }

  return (
    <Card className="bg-gaming-surface border-gaming-yellow/20">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
          <Trophy className="h-5 w-5 mr-2" />
          Atualizar Troféus das Divisões
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Division Selection */}
            <FormField
              control={form.control}
              name="divisionId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Divisão *</FormLabel>
                  <Select 
                    onValueChange={(value) => {
                      field.onChange(value);
                      handleDivisionSelect(value);
                    }}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                        <SelectValue placeholder="Selecione a divisão" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-gaming-card border-gray-600">
                      {divisions.map((division) => (
                        <SelectItem key={division.id} value={division.id}>
                          <div className="flex items-center space-x-2">
                            <Badge 
                              style={{ backgroundColor: division.color }}
                              className="text-white"
                            >
                              {division.name}
                            </Badge>
                            <span className="text-gray-300">
                              ({division.currentTrophies.toLocaleString()} troféus)
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Current Status */}
            {selectedDivision && (
              <div className="p-4 bg-gaming-card rounded-lg border border-gaming-yellow/20">
                <h4 className="font-semibold text-white mb-2">Status Atual</h4>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Troféus Atuais:</span>
                    <p className="text-gaming-yellow font-bold">
                      {selectedDivision.currentTrophies.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-400">Variação Mensal:</span>
                    <p className={`font-bold flex items-center ${
                      selectedDivision.monthlyVariation >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {selectedDivision.monthlyVariation >= 0 ? (
                        <TrendingUp className="h-4 w-4 mr-1" />
                      ) : (
                        <TrendingDown className="h-4 w-4 mr-1" />
                      )}
                      {selectedDivision.monthlyVariation >= 0 ? '+' : ''}{selectedDivision.monthlyVariation}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-400">Jogadores Ativos:</span>
                    <p className="text-white font-bold flex items-center">
                      <Activity className="h-4 w-4 mr-1" />
                      {selectedDivision.activePlayers}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* New Trophies Input */}
            <FormField
              control={form.control}
              name="newTrophies"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Nova Quantidade de Troféus *</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="number"
                      min="0"
                      step="1"
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="Digite a nova quantidade"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Difference Preview */}
            {selectedDivision && difference !== 0 && (
              <div className={`p-3 rounded-lg border ${
                difference > 0 
                  ? 'bg-green-900/20 border-green-500/30' 
                  : 'bg-red-900/20 border-red-500/30'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-white">Diferença:</span>
                  <span className={`font-bold text-lg flex items-center ${
                    difference > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {difference > 0 ? (
                      <TrendingUp className="h-5 w-5 mr-1" />
                    ) : (
                      <TrendingDown className="h-5 w-5 mr-1" />
                    )}
                    {difference > 0 ? '+' : ''}{difference.toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-gray-400 mt-1">
                  {difference > 0 ? '🎉 Crescimento!' : '📉 Redução'}
                  {Math.abs(difference) >= 1000 && ' (Mudança significativa)'}
                </p>
              </div>
            )}

            <Button
              type="submit"
              disabled={isSubmitting || !selectedDivision || difference === 0}
              className="w-full bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
            >
              {isSubmitting ? "Atualizando..." : "Atualizar Troféus"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}