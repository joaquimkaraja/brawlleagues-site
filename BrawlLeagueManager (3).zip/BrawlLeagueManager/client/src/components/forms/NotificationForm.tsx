import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { addDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Bell, AlertCircle, Info, CheckCircle } from "lucide-react";

const notificationSchema = z.object({
  title: z.string().min(3, "Título deve ter pelo menos 3 caracteres"),
  message: z.string().min(10, "Mensagem deve ter pelo menos 10 caracteres"),
  type: z.enum(["info", "warning", "error", "success"], { required_error: "Selecione um tipo" }),
  priority: z.enum(["low", "medium", "high"], { required_error: "Selecione uma prioridade" }),
  expirationDays: z.number().min(1, "Mínimo 1 dia").max(30, "Máximo 30 dias"),
});

type NotificationForm = z.infer<typeof notificationSchema>;

interface NotificationFormProps {
  onSuccess: () => void;
  userRole: string;
}

const NOTIFICATION_TYPES = [
  { value: "info", label: "Informação", icon: Info, color: "text-blue-400" },
  { value: "warning", label: "Aviso", icon: AlertCircle, color: "text-yellow-400" },
  { value: "error", label: "Erro", icon: AlertCircle, color: "text-red-400" },
  { value: "success", label: "Sucesso", icon: CheckCircle, color: "text-green-400" },
];

const PRIORITY_LEVELS = [
  { value: "low", label: "Baixa", description: "Notificação discreta" },
  { value: "medium", label: "Média", description: "Notificação padrão" },
  { value: "high", label: "Alta", description: "Notificação destacada" },
];

export function NotificationForm({ onSuccess, userRole }: NotificationFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<NotificationForm>({
    resolver: zodResolver(notificationSchema),
    defaultValues: {
      title: "",
      message: "",
      type: "info",
      priority: "medium",
      expirationDays: 7,
    },
  });

  const onSubmit = async (data: NotificationForm) => {
    setIsSubmitting(true);
    try {
      const expirationDate = new Date();
      expirationDate.setDate(expirationDate.getDate() + data.expirationDays);

      await addDocument("notifications", {
        title: data.title,
        message: data.message,
        type: data.type,
        priority: data.priority,
        isRead: false,
        expiresAt: expirationDate,
      });

      // Add action history
      await addDocument("actionHistory", {
        action: "notification_created",
        description: `Notificação "${data.title}" criada`,
        performedBy: userRole,
        entityType: "notification",
      });

      toast({
        title: "Sucesso!",
        description: "Notificação criada com sucesso!",
      });

      form.reset();
      onSuccess();
    } catch (error) {
      console.error("Error creating notification:", error);
      toast({
        title: "Erro",
        description: "Erro ao criar notificação. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedType = NOTIFICATION_TYPES.find(t => t.value === form.watch("type"));

  return (
    <Card className="bg-gaming-surface border-gaming-yellow/20">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
          <Bell className="h-5 w-5 mr-2" />
          Criar Notificação/Aviso
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Título *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                        placeholder="Ex: Manutenção programada"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Type */}
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Tipo *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-gaming-card border-gray-600">
                        {NOTIFICATION_TYPES.map((type) => {
                          const IconComponent = type.icon;
                          return (
                            <SelectItem key={type.value} value={type.value}>
                              <div className="flex items-center space-x-2">
                                <IconComponent className={`h-4 w-4 ${type.color}`} />
                                <span>{type.label}</span>
                              </div>
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Priority */}
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Prioridade *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-gaming-card border-gray-600">
                        {PRIORITY_LEVELS.map((priority) => (
                          <SelectItem key={priority.value} value={priority.value}>
                            <div>
                              <div className="font-medium">{priority.label}</div>
                              <div className="text-xs text-gray-400">{priority.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Expiration Days */}
              <FormField
                control={form.control}
                name="expirationDays"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Expira em (dias) *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        min="1"
                        max="30"
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                        placeholder="7"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Message */}
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Mensagem *</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="Descreva a notificação ou aviso..."
                      rows={4}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Preview */}
            {form.watch("title") && form.watch("message") && (
              <div className="p-4 bg-gaming-card rounded-lg border border-gaming-yellow/20">
                <h4 className="text-white mb-2">Prévia:</h4>
                <div className={`p-3 rounded-lg border-l-4 ${
                  selectedType?.value === "success" ? "bg-green-900/20 border-green-500" :
                  selectedType?.value === "warning" ? "bg-yellow-900/20 border-yellow-500" :
                  selectedType?.value === "error" ? "bg-red-900/20 border-red-500" :
                  "bg-blue-900/20 border-blue-500"
                }`}>
                  <div className="flex items-center space-x-2 mb-2">
                    {selectedType && (
                      <selectedType.icon className={`h-4 w-4 ${selectedType.color}`} />
                    )}
                    <span className="font-semibold text-white">{form.watch("title")}</span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      form.watch("priority") === "high" ? "bg-red-600" :
                      form.watch("priority") === "medium" ? "bg-yellow-600" :
                      "bg-gray-600"
                    } text-white`}>
                      {PRIORITY_LEVELS.find(p => p.value === form.watch("priority"))?.label}
                    </span>
                  </div>
                  <p className="text-gray-300 text-sm">{form.watch("message")}</p>
                </div>
              </div>
            )}

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
            >
              {isSubmitting ? "Criando..." : "Criar Notificação"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}