import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { getDocuments, addDocument, updateDocument, deleteDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { User, Trash2, Edit, Users, Crown, AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const memberSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  divisionId: z.string().min(1, "Selecione uma divisão"),
});

type MemberForm = z.infer<typeof memberSchema>;

interface Member {
  id: string;
  name: string;
  divisionId: string;
  totalFriendlies: number;
  victories: number;
  createdAt: any;
}

interface Division {
  id: string;
  name: string;
  color: string;
}

interface MemberManagementFormProps {
  userRole: string;
}

export function MemberManagementForm({ userRole }: MemberManagementFormProps) {
  const [members, setMembers] = useState<Member[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const { toast } = useToast();

  const form = useForm<MemberForm>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      name: "",
      divisionId: "",
    },
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [membersData, divisionsData] = await Promise.all([
        getDocuments("members"),
        getDocuments("divisions")
      ]);
      
      setMembers(membersData as Member[]);
      setDivisions(divisionsData as Division[]);
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: MemberForm) => {
    setIsSubmitting(true);
    try {
      await addDocument("members", {
        name: data.name,
        divisionId: data.divisionId,
        totalFriendlies: 0,
        victories: 0,
      });

      // Add action history
      await addDocument("actionHistory", {
        action: "member_created",
        description: `Membro "${data.name}" cadastrado`,
        performedBy: userRole,
        entityType: "member",
      });

      toast({
        title: "Sucesso!",
        description: "Membro cadastrado com sucesso!",
      });

      form.reset();
      loadData();
    } catch (error) {
      console.error("Error creating member:", error);
      toast({
        title: "Erro",
        description: "Erro ao cadastrar membro. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTransferDivision = async (newDivisionId: string) => {
    if (selectedMembers.length === 0) return;

    try {
      const division = divisions.find(d => d.id === newDivisionId);
      
      for (const memberId of selectedMembers) {
        await updateDocument("members", memberId, {
          divisionId: newDivisionId,
        });
      }

      // Add action history
      await addDocument("actionHistory", {
        action: "members_transferred",
        description: `${selectedMembers.length} membros transferidos para ${division?.name}`,
        performedBy: userRole,
        entityType: "member",
      });

      toast({
        title: "Sucesso!",
        description: `${selectedMembers.length} membros transferidos com sucesso!`,
      });

      setSelectedMembers([]);
      loadData();
    } catch (error) {
      console.error("Error transferring members:", error);
      toast({
        title: "Erro",
        description: "Erro ao transferir membros.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteMembers = async () => {
    if (selectedMembers.length === 0 || userRole !== "soberano") return;

    try {
      for (const memberId of selectedMembers) {
        await deleteDocument("members", memberId);
      }

      // Add action history
      await addDocument("actionHistory", {
        action: "members_deleted",
        description: `${selectedMembers.length} membros removidos definitivamente`,
        performedBy: userRole,
        entityType: "member",
      });

      toast({
        title: "Sucesso!",
        description: `${selectedMembers.length} membros removidos com sucesso!`,
      });

      setSelectedMembers([]);
      setShowDeleteConfirm(false);
      loadData();
    } catch (error) {
      console.error("Error deleting members:", error);
      toast({
        title: "Erro",
        description: "Erro ao remover membros.",
        variant: "destructive",
      });
    }
  };

  const toggleMemberSelection = (memberId: string) => {
    setSelectedMembers(prev =>
      prev.includes(memberId)
        ? prev.filter(id => id !== memberId)
        : [...prev, memberId]
    );
  };

  const getDivisionById = (divisionId: string) => {
    return divisions.find(d => d.id === divisionId);
  };

  const getVictoryPercentage = (victories: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((victories / total) * 100);
  };

  if (isLoading) {
    return <div className="text-center text-gray-400 py-8">Carregando...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Add Member Form */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
            <User className="h-5 w-5 mr-2" />
            Cadastrar Novo Membro
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Nome do Membro *</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                          placeholder="Digite o nome"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="divisionId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Divisão *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                            <SelectValue placeholder="Selecione a divisão" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-gaming-card border-gray-600">
                          {divisions.map((division) => (
                            <SelectItem key={division.id} value={division.id}>
                              {division.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
              >
                {isSubmitting ? "Cadastrando..." : "Cadastrar Membro"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Bulk Actions */}
      {selectedMembers.length > 0 && (
        <Card className="bg-gaming-surface border-gaming-yellow/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <span className="text-white">
                {selectedMembers.length} membro(s) selecionado(s)
              </span>
              <div className="flex space-x-2">
                <Select onValueChange={handleTransferDivision}>
                  <SelectTrigger className="w-48 bg-gaming-card border-gray-600 text-white">
                    <SelectValue placeholder="Transferir para..." />
                  </SelectTrigger>
                  <SelectContent className="bg-gaming-card border-gray-600">
                    {divisions.map((division) => (
                      <SelectItem key={division.id} value={division.id}>
                        {division.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {userRole === "soberano" && (
                  <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
                    <DialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4 mr-1" />
                        Remover
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-gaming-surface border-gaming-yellow/20 text-white">
                      <DialogHeader>
                        <DialogTitle className="flex items-center text-red-400">
                          <AlertTriangle className="h-5 w-5 mr-2" />
                          Confirmar Exclusão
                        </DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <p className="text-gray-300">
                          ⚠️ Tem certeza? Esta ação é irreversível e removerá permanentemente {selectedMembers.length} membro(s).
                        </p>
                        <div className="flex space-x-2 justify-end">
                          <Button
                            variant="outline"
                            onClick={() => setShowDeleteConfirm(false)}
                          >
                            Cancelar
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={handleDeleteMembers}
                          >
                            Remover Definitivamente
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Members List */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Membros Cadastrados ({members.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {members.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum membro cadastrado
            </div>
          ) : (
            <div className="space-y-2">
              {members.map((member) => {
                const division = getDivisionById(member.divisionId);
                const winPercentage = getVictoryPercentage(member.victories, member.totalFriendlies);
                
                return (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-3 bg-gaming-card rounded-lg hover:bg-gaming-card/80 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        checked={selectedMembers.includes(member.id)}
                        onCheckedChange={() => toggleMemberSelection(member.id)}
                        className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                      />
                      <div className="w-10 h-10 bg-gaming-yellow rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-gaming-dark" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{member.name}</h4>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            style={{ backgroundColor: division?.color }}
                            className="text-white"
                          >
                            {division?.name}
                          </Badge>
                          <span className="text-sm text-gray-400">
                            {member.totalFriendlies} amistosos • {member.victories} vitórias
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold text-gaming-yellow">
                        {winPercentage}%
                      </span>
                      <p className="text-xs text-gray-400">Taxa de vitória</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}