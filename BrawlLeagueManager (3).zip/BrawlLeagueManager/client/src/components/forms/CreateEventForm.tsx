import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { addDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { CalendarDays, Users, Trophy, Zap, Star, Flame } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

const eventSchema = z.object({
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  type: z.string().min(1, "Selecione o tipo de evento"),
  description: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  maxParticipants: z.number().min(2, "Mínimo 2 participantes"),
  startDate: z.string().min(1, "Data de início é obrigatória"),
  endDate: z.string().min(1, "Data de fim é obrigatória"),
  requiresRegistration: z.boolean(),
  teamRegistration: z.boolean(),
  minTeamSize: z.number().min(3).max(6).optional(),
  maxTeamSize: z.number().min(3).max(6).optional(),
});

type EventForm = z.infer<typeof eventSchema>;

interface CreateEventFormProps {
  onSuccess: () => void;
  userRole: string;
}

const EVENT_TYPES = [
  { 
    value: "tournament", 
    label: "Campeonato por Etapas", 
    icon: Trophy,
    description: "Eliminação única com chaveamento visual"
  },
  { 
    value: "combat", 
    label: "Evento de Combate", 
    icon: Flame,
    description: "Solo ou Duo com critérios de pontuação"
  },
  { 
    value: "marathon", 
    label: "Maratona de Troféus", 
    icon: Zap,
    description: "Ranking por maior crescimento de troféus"
  },
  { 
    value: "ranking", 
    label: "Ranking Geral", 
    icon: Star,
    description: "Múltiplas métricas combinadas"
  },
  { 
    value: "flash", 
    label: "Evento Flash", 
    icon: CalendarDays,
    description: "Duração curta (2-6 horas)"
  },
  { 
    value: "mvp", 
    label: "Caça ao MVP", 
    icon: Users,
    description: "Sistema de medalhas virtuais"
  }
];

export function CreateEventForm({ onSuccess, userRole }: CreateEventFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedType, setSelectedType] = useState<string>("");
  const { toast } = useToast();

  const form = useForm<EventForm>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      name: "",
      type: "",
      description: "",
      maxParticipants: 16,
      startDate: "",
      endDate: "",
      requiresRegistration: true,
      teamRegistration: false,
      minTeamSize: 3,
      maxTeamSize: 6,
    },
  });

  const getParticipantOptions = (eventType: string) => {
    switch (eventType) {
      case "tournament":
        return [8, 16, 32, 64];
      case "combat":
        return [6, 8, 10, 12];
      case "marathon":
        return [20, 30, 50, 100];
      case "flash":
        return [10, 15, 20, 25];
      default:
        return [8, 16, 24, 32];
    }
  };

  const onSubmit = async (data: EventForm) => {
    setIsSubmitting(true);
    try {
      const eventConfig = getEventConfiguration(data.type, data);
      
      await addDocument("events", {
        name: data.name,
        type: data.type,
        description: data.description,
        maxParticipants: data.maxParticipants,
        currentParticipants: 0,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
        status: "draft",
        isPublicVisible: data.requiresRegistration,
        configuration: {
          ...eventConfig,
          requiresRegistration: data.requiresRegistration,
          teamRegistration: data.teamRegistration,
          minTeamSize: data.minTeamSize,
          maxTeamSize: data.maxTeamSize,
        },
      });

      // Add action history
      await addDocument("actionHistory", {
        action: "event_created",
        description: `Evento "${data.name}" criado`,
        performedBy: userRole,
        entityType: "event",
      });

      toast({
        title: "Sucesso!",
        description: "Evento criado com sucesso!",
      });

      form.reset();
      setSelectedType("");
      onSuccess();
    } catch (error) {
      console.error("Error creating event:", error);
      toast({
        title: "Erro",
        description: "Erro ao criar evento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getEventConfiguration = (eventType: string, data: EventForm) => {
    const baseConfig = {
      rules: data.description,
      maxParticipants: data.maxParticipants,
    };

    switch (eventType) {
      case "tournament":
        return {
          ...baseConfig,
          eliminationType: "single",
          bracketStyle: "standard",
          teamsRequired: data.maxParticipants,
          mapsPerPhase: {
            quarterfinals: 1,
            semifinals: 1,
            final: 3
          }
        };
      case "combat":
        return {
          ...baseConfig,
          mode: "solo", // or "duo"
          scoringCriteria: "eliminations", // or "final_position"
          maxPlayersPerRoom: 10
        };
      case "marathon":
        return {
          ...baseConfig,
          trackingType: "trophy_growth",
          minimumIncrease: 100,
          timeLimit: "7_days"
        };
      case "ranking":
        return {
          ...baseConfig,
          metrics: ["friendly_wins", "mvp_count", "activity_score"],
          weightings: { wins: 40, mvp: 35, activity: 25 }
        };
      case "flash":
        return {
          ...baseConfig,
          duration: "4_hours",
          realTimeRanking: true,
          quickActions: ["fast_wins", "rapid_climbs"]
        };
      case "mvp":
        return {
          ...baseConfig,
          medals: ["event_mvp", "revelation", "sportsmanship"],
          votingSystem: "peer_review"
        };
      default:
        return baseConfig;
    }
  };

  const selectedEventType = EVENT_TYPES.find(type => type.value === selectedType);

  return (
    <Card className="bg-gaming-surface border-gaming-yellow/20">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gaming-yellow">
          Criar Novo Evento
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Event Type Selection */}
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Tipo de Evento *</FormLabel>
                  <Select 
                    onValueChange={(value) => {
                      field.onChange(value);
                      setSelectedType(value);
                    }} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                        <SelectValue placeholder="Selecione o tipo de evento" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-gaming-card border-gray-600">
                      {EVENT_TYPES.map((eventType) => {
                        const IconComponent = eventType.icon;
                        return (
                          <SelectItem key={eventType.value} value={eventType.value}>
                            <div className="flex items-center space-x-2">
                              <IconComponent className="h-4 w-4 text-gaming-yellow" />
                              <span>{eventType.label}</span>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Event Type Description */}
            {selectedEventType && (
              <div className="p-3 bg-gaming-card rounded-lg border border-gaming-yellow/20">
                <p className="text-sm text-gray-300">{selectedEventType.description}</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Event Name */}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Nome do Evento *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                        placeholder="Ex: Campeonato Luminous"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Max Participants */}
              <FormField
                control={form.control}
                name="maxParticipants"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Número de Participantes *</FormLabel>
                    <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                      <FormControl>
                        <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-gaming-card border-gray-600">
                        {getParticipantOptions(selectedType).map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num} Participantes
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Start Date */}
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Data de Início *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="datetime-local"
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* End Date */}
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Data de Fim *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="datetime-local"
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Descrição Detalhada *</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="Descreva as regras e formato do evento"
                      rows={4}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Registration Options */}
            <div className="space-y-4 p-4 bg-gaming-card rounded-lg border border-gaming-yellow/20">
              <h4 className="font-semibold text-white">Opções de Inscrição</h4>
              
              <FormField
                control={form.control}
                name="requiresRegistration"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-gray-300">
                        Requer inscrição pública
                      </FormLabel>
                      <p className="text-sm text-gray-400">
                        Se marcado, o evento aparecerá no dashboard público para inscrições
                      </p>
                    </div>
                  </FormItem>
                )}
              />

              {form.watch("requiresRegistration") && (
                <>
                  <FormField
                    control={form.control}
                    name="teamRegistration"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="text-gray-300">
                            Inscrição por equipes
                          </FormLabel>
                          <p className="text-sm text-gray-400">
                            Se marcado, permite inscrição de equipes. Caso contrário, apenas jogadores individuais
                          </p>
                        </div>
                      </FormItem>
                    )}
                  />

                  {form.watch("teamRegistration") && (
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="minTeamSize"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Mín. jogadores por equipe</FormLabel>
                            <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                              <FormControl>
                                <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                                  <SelectValue placeholder="Mínimo" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-gaming-card border-gray-600">
                                {[3, 4, 5, 6].map((num) => (
                                  <SelectItem key={num} value={num.toString()}>
                                    {num} jogadores
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="maxTeamSize"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Máx. jogadores por equipe</FormLabel>
                            <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                              <FormControl>
                                <SelectTrigger className="bg-gaming-card border-gray-600 text-white">
                                  <SelectValue placeholder="Máximo" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-gaming-card border-gray-600">
                                {[3, 4, 5, 6].map((num) => (
                                  <SelectItem key={num} value={num.toString()}>
                                    {num} jogadores
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                </>
              )}
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
            >
              {isSubmitting ? "Criando..." : "Criar Evento"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}