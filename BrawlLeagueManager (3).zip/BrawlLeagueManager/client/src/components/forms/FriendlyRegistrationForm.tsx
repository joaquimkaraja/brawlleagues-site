import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { getDocuments, addDocument, updateDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Gamepad2, Clock, Users, Trophy } from "lucide-react";

const friendlySchema = z.object({
  date: z.string().min(1, "Data é obrigatória"),
  duration: z.number().min(1, "Duração deve ser pelo menos 1 minuto"),
  divisions: z.array(z.string()).min(1, "Selecione pelo menos uma divisão"),
  participants: z.array(z.string()).min(2, "Selecione pelo menos 2 participantes"),
  winners: z.array(z.string()).min(1, "Selecione pelo menos um vencedor"),
});

type FriendlyForm = z.infer<typeof friendlySchema>;

interface Member {
  id: string;
  name: string;
  divisionId: string;
  totalFriendlies: number;
  victories: number;
}

interface Division {
  id: string;
  name: string;
  color: string;
}

interface FriendlyRegistrationFormProps {
  userRole: string;
}

export function FriendlyRegistrationForm({ userRole }: FriendlyRegistrationFormProps) {
  const [members, setMembers] = useState<Member[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [selectedDivisions, setSelectedDivisions] = useState<string[]>([]);
  const [availableParticipants, setAvailableParticipants] = useState<Member[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<FriendlyForm>({
    resolver: zodResolver(friendlySchema),
    defaultValues: {
      date: "",
      duration: 10,
      divisions: [],
      participants: [],
      winners: [],
    },
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    // Filter participants based on selected divisions
    const filtered = members.filter(member => 
      selectedDivisions.includes(member.divisionId)
    );
    setAvailableParticipants(filtered);
    
    // Reset participants and winners when divisions change
    form.setValue("participants", []);
    form.setValue("winners", []);
  }, [selectedDivisions, members, form]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [membersData, divisionsData] = await Promise.all([
        getDocuments("members"),
        getDocuments("divisions")
      ]);
      
      setMembers(membersData as Member[]);
      setDivisions(divisionsData as Division[]);
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: FriendlyForm) => {
    setIsSubmitting(true);
    try {
      // Get participant names
      const participantNames = data.participants.map(id => 
        members.find(m => m.id === id)?.name || ""
      ).filter(Boolean);

      const winnerNames = data.winners.map(id => 
        members.find(m => m.id === id)?.name || ""
      ).filter(Boolean);

      // Register the friendly
      await addDocument("friendlies", {
        date: new Date(data.date),
        duration: data.duration,
        divisions: data.divisions,
        participants: participantNames,
        winners: winnerNames,
      });

      // Update member statistics
      for (const participantId of data.participants) {
        const member = members.find(m => m.id === participantId);
        if (member) {
          const isWinner = data.winners.includes(participantId);
          await updateDocument("members", participantId, {
            totalFriendlies: member.totalFriendlies + 1,
            victories: isWinner ? member.victories + 1 : member.victories,
          });
        }
      }

      // Add action history
      await addDocument("actionHistory", {
        action: "friendly_registered",
        description: `Amistoso registrado: ${participantNames.length} participantes, vencedores: ${winnerNames.join(", ")}`,
        performedBy: userRole,
        entityType: "friendly",
      });

      toast({
        title: "Sucesso!",
        description: "Amistoso registrado com sucesso!",
      });

      form.reset();
      setSelectedDivisions([]);
      loadData();
    } catch (error) {
      console.error("Error registering friendly:", error);
      toast({
        title: "Erro",
        description: "Erro ao registrar amistoso. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDivisionToggle = (divisionId: string) => {
    const newSelectedDivisions = selectedDivisions.includes(divisionId)
      ? selectedDivisions.filter(id => id !== divisionId)
      : [...selectedDivisions, divisionId];
    
    setSelectedDivisions(newSelectedDivisions);
    form.setValue("divisions", newSelectedDivisions);
  };

  const handleParticipantToggle = (participantId: string) => {
    const currentParticipants = form.getValues("participants");
    const newParticipants = currentParticipants.includes(participantId)
      ? currentParticipants.filter(id => id !== participantId)
      : [...currentParticipants, participantId];
    
    form.setValue("participants", newParticipants);
    
    // Reset winners if they're no longer participants
    const currentWinners = form.getValues("winners");
    const validWinners = currentWinners.filter(winner => newParticipants.includes(winner));
    form.setValue("winners", validWinners);
  };

  const getDivisionById = (divisionId: string) => {
    return divisions.find(d => d.id === divisionId);
  };

  const selectedParticipants = form.watch("participants") || [];

  if (isLoading) {
    return <div className="text-center text-gray-400 py-8">Carregando...</div>;
  }

  return (
    <Card className="bg-gaming-surface border-gaming-yellow/20">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
          <Gamepad2 className="h-5 w-5 mr-2" />
          Registrar Amistoso
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Date */}
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Data *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="datetime-local"
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Duration */}
              <FormField
                control={form.control}
                name="duration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Duração (minutos) *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        min="1"
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                        placeholder="Ex: 15"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Divisions Selection */}
            <FormField
              control={form.control}
              name="divisions"
              render={() => (
                <FormItem>
                  <FormLabel className="text-gray-300">Divisões Envolvidas (até 4) *</FormLabel>
                  <div className="grid grid-cols-2 gap-2">
                    {divisions.map((division) => (
                      <div key={division.id} className="flex items-center space-x-2">
                        <Checkbox
                          checked={selectedDivisions.includes(division.id)}
                          onCheckedChange={() => handleDivisionToggle(division.id)}
                          disabled={selectedDivisions.length >= 4 && !selectedDivisions.includes(division.id)}
                          className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                        />
                        <Badge 
                          style={{ backgroundColor: division.color }}
                          className="text-white"
                        >
                          {division.name}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Participants Selection */}
            {availableParticipants.length > 0 && (
              <FormField
                control={form.control}
                name="participants"
                render={() => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Participantes *</FormLabel>
                    <div className="max-h-40 overflow-y-auto space-y-2 border border-gray-600 rounded-lg p-3 bg-gaming-card">
                      {availableParticipants.map((member) => {
                        const division = getDivisionById(member.divisionId);
                        return (
                          <div key={member.id} className="flex items-center space-x-2">
                            <Checkbox
                              checked={selectedParticipants.includes(member.id)}
                              onCheckedChange={() => handleParticipantToggle(member.id)}
                              className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                            />
                            <span className="text-white">{member.name}</span>
                            <Badge 
                              style={{ backgroundColor: division?.color }}
                              className="text-white text-xs"
                            >
                              {division?.name}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Winners Selection */}
            {selectedParticipants.length > 0 && (
              <FormField
                control={form.control}
                name="winners"
                render={() => (
                  <FormItem>
                    <FormLabel className="text-gray-300">Vencedores *</FormLabel>
                    <div className="max-h-40 overflow-y-auto space-y-2 border border-gray-600 rounded-lg p-3 bg-gaming-card">
                      {selectedParticipants.map((participantId) => {
                        const member = members.find(m => m.id === participantId);
                        const division = getDivisionById(member?.divisionId || "");
                        const currentWinners = form.watch("winners") || [];
                        
                        return (
                          <div key={participantId} className="flex items-center space-x-2">
                            <Checkbox
                              checked={currentWinners.includes(participantId)}
                              onCheckedChange={(checked) => {
                                const newWinners = checked
                                  ? [...currentWinners, participantId]
                                  : currentWinners.filter(id => id !== participantId);
                                form.setValue("winners", newWinners);
                              }}
                              className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                            />
                            <span className="text-white">{member?.name}</span>
                            <Badge 
                              style={{ backgroundColor: division?.color }}
                              className="text-white text-xs"
                            >
                              {division?.name}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <Button
              type="submit"
              disabled={isSubmitting || selectedParticipants.length === 0 || (form.watch("winners") || []).length === 0}
              className="w-full bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
            >
              {isSubmitting ? "Registrando..." : "Registrar Amistoso"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}