import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { getDocuments, deleteDocument, addDocument } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Trash2, AlertTriangle, Users } from "lucide-react";

interface Member {
  id: string;
  name: string;
  divisionId: string;
  totalFriendlies: number;
  victories: number;
}

interface Division {
  id: string;
  name: string;
  color: string;
}

interface MemberRemovalFormProps {
  userRole: string;
}

export function MemberRemovalForm({ userRole }: MemberRemovalFormProps) {
  const [members, setMembers] = useState<Member[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [membersData, divisionsData] = await Promise.all([
        getDocuments("members"),
        getDocuments("divisions")
      ]);
      
      setMembers(membersData as Member[]);
      setDivisions(divisionsData as Division[]);
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleMemberToggle = (memberId: string) => {
    setSelectedMembers(prev =>
      prev.includes(memberId)
        ? prev.filter(id => id !== memberId)
        : [...prev, memberId]
    );
  };

  const handleDeleteMembers = async () => {
    if (selectedMembers.length === 0 || (userRole !== "soberano" && userRole !== "oficial")) return;

    setIsDeleting(true);
    try {
      const memberNames = selectedMembers.map(id => 
        members.find(m => m.id === id)?.name || ""
      ).filter(Boolean);

      // Delete members from Firebase
      for (const memberId of selectedMembers) {
        await deleteDocument("members", memberId);
      }

      // Add action history
      await addDocument("actionHistory", {
        action: "members_deleted",
        description: `${selectedMembers.length} membros removidos: ${memberNames.join(", ")}`,
        performedBy: userRole,
        entityType: "member",
      });

      toast({
        title: "Sucesso!",
        description: `${selectedMembers.length} membros removidos permanentemente!`,
      });

      setSelectedMembers([]);
      setShowDeleteConfirm(false);
      loadData();
    } catch (error) {
      console.error("Error deleting members:", error);
      toast({
        title: "Erro",
        description: "Erro ao remover membros.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const getDivisionById = (divisionId: string) => {
    return divisions.find(d => d.id === divisionId);
  };

  const getVictoryPercentage = (victories: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((victories / total) * 100);
  };

  if (userRole !== "soberano" && userRole !== "oficial") {
    return (
      <Card className="bg-gaming-surface border-red-500/20">
        <CardContent className="p-6 text-center">
          <div className="text-red-400 mb-2">🔒 Acesso Restrito</div>
          <p className="text-gray-400">Apenas Soberano e Alto Oficial podem remover membros</p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return <div className="text-center text-gray-400 py-8">Carregando...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gaming-yellow flex items-center">
            <Trash2 className="h-5 w-5 mr-2" />
            Remover Membros das Divisões
          </CardTitle>
          <p className="text-gray-400 text-sm">
            ⚠️ Atenção: Membros removidos serão excluídos permanentemente do Firebase
          </p>
        </CardHeader>
      </Card>

      {/* Bulk Actions */}
      {selectedMembers.length > 0 && (
        <Card className="bg-gaming-surface border-red-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <span className="text-white">
                {selectedMembers.length} membro(s) selecionado(s) para remoção
              </span>
              <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
                <DialogTrigger asChild>
                  <Button variant="destructive">
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remover Permanentemente
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gaming-surface border-gaming-yellow/20 text-white">
                  <DialogHeader>
                    <DialogTitle className="flex items-center text-red-400">
                      <AlertTriangle className="h-5 w-5 mr-2" />
                      Confirmar Exclusão Definitiva
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="p-4 bg-red-900/20 border border-red-500/30 rounded-lg">
                      <p className="text-red-300 font-semibold mb-2">
                        ⚠️ AÇÃO IRREVERSÍVEL
                      </p>
                      <p className="text-gray-300">
                        Esta ação removerá permanentemente {selectedMembers.length} membro(s) do sistema:
                      </p>
                      <ul className="mt-2 space-y-1">
                        {selectedMembers.map(id => {
                          const member = members.find(m => m.id === id);
                          const division = getDivisionById(member?.divisionId || "");
                          return (
                            <li key={id} className="flex items-center space-x-2">
                              <span className="text-white">• {member?.name}</span>
                              <Badge 
                                style={{ backgroundColor: division?.color }}
                                className="text-white text-xs"
                              >
                                {division?.name}
                              </Badge>
                            </li>
                          );
                        })}
                      </ul>
                      <p className="text-red-300 text-sm mt-3">
                        Os dados de histórico e estatísticas destes membros serão perdidos permanentemente.
                      </p>
                    </div>
                    <div className="flex space-x-2 justify-end">
                      <Button
                        variant="outline"
                        onClick={() => setShowDeleteConfirm(false)}
                        disabled={isDeleting}
                      >
                        Cancelar
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={handleDeleteMembers}
                        disabled={isDeleting}
                      >
                        {isDeleting ? "Removendo..." : "Confirmar Exclusão"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Members List */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-white flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Selecionar Membros para Remoção ({members.length} total)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {members.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum membro cadastrado
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {members.map((member) => {
                const division = getDivisionById(member.divisionId);
                const winPercentage = getVictoryPercentage(member.victories, member.totalFriendlies);
                
                return (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-3 bg-gaming-card rounded-lg hover:bg-gaming-card/80 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        checked={selectedMembers.includes(member.id)}
                        onCheckedChange={() => handleMemberToggle(member.id)}
                        className="border-gray-600 data-[state=checked]:bg-red-600 data-[state=checked]:border-red-600"
                      />
                      <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                        <Users className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{member.name}</h4>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            style={{ backgroundColor: division?.color }}
                            className="text-white"
                          >
                            {division?.name}
                          </Badge>
                          <span className="text-sm text-gray-400">
                            {member.totalFriendlies} amistosos • {member.victories} vitórias
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-bold text-gaming-yellow">
                        {winPercentage}%
                      </span>
                      <p className="text-xs text-gray-400">Taxa de vitória</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}