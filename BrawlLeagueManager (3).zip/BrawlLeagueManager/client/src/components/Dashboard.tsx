import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Crown, Flame, VenetianMask, Zap, Trophy, Star, Users, TrendingUp, TrendingDown } from "lucide-react";
import { TrophyChart } from "./TrophyChart";
import { EventRegistration } from "./EventRegistration";
import { DashboardStats } from "./DashboardStats";
import { getDocuments } from "@/lib/firebase";
import { where } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";

interface Division {
  id: string;
  name: string;
  currentTrophies: number;
  monthlyVariation: number;
  activePlayers: number;
  icon: string;
  color: string;
}

interface Event {
  id: string;
  name: string;
  description: string;
  type: string;
  status: string;
  maxParticipants: number;
  currentParticipants: number;
  startDate: any;
  endDate: any;
}

const iconMap = {
  crown: Crown,
  fire: Flame,
  mask: VenetianMask,
  bolt: Zap,
};

export function Dashboard() {
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [activeEvents, setActiveEvents] = useState<Event[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showRegistration, setShowRegistration] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [divisionsData, eventsData] = await Promise.all([
        getDocuments("divisions"),
        getDocuments("events", [where("status", "in", ["open", "active"])])
      ]);
      
      setDivisions(divisionsData as Division[]);
      setActiveEvents(eventsData as Event[]);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados do dashboard",
        variant: "destructive",
      });
    }
  };

  const handleEventRegistration = (event: Event) => {
    setSelectedEvent(event);
    setShowRegistration(true);
  };

  const getDivisionIcon = (iconName: string) => {
    const IconComponent = iconMap[iconName as keyof typeof iconMap] || Trophy;
    return IconComponent;
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      open: { label: "ABERTO", variant: "default" as const, className: "bg-green-500 hover:bg-green-600" },
      active: { label: "ATIVO", variant: "secondary" as const, className: "bg-gaming-yellow text-gaming-dark" },
      completed: { label: "FINALIZADO", variant: "outline" as const, className: "bg-gray-600" },
    };
    
    return statusMap[status as keyof typeof statusMap] || statusMap.open;
  };

  return (
    <div className="min-h-screen bg-gaming-dark text-white">
      {/* Hero Section */}
      <div className="text-center py-16 px-4">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
          Brawl <span className="text-gaming-yellow">Leagues</span>
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Sistema de gerenciamento para comunidade Brawl Leagues.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        {/* Division Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {divisions.map((division) => {
            const IconComponent = getDivisionIcon(division.icon);
            const isPositive = division.monthlyVariation > 0;
            
            return (
              <Card key={division.id} className="bg-gaming-surface border-gaming-yellow/20 hover:border-gaming-yellow/40 transition-all hover:shadow-lg hover:shadow-gaming-yellow/20">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-lg font-semibold text-white">{division.name}</CardTitle>
                  <IconComponent 
                    className="h-6 w-6" 
                    style={{ color: division.color }}
                  />
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Troféus Atuais</span>
                    <span className="text-2xl font-bold text-gaming-yellow">
                      {division.currentTrophies.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Variação Mensal</span>
                    <span className={`font-medium flex items-center ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                      {isPositive ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                      {isPositive ? '+' : ''}{division.monthlyVariation.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Jogadores Ativos</span>
                    <span className="text-white font-medium">{division.activePlayers}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <TrophyChart />
          
          <Card className="bg-gaming-surface border-gaming-yellow/20">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-white">Destaques do Mês</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4 p-4 bg-gaming-card rounded-lg">
                <div className="w-12 h-12 bg-gaming-yellow rounded-full flex items-center justify-center">
                  <Crown className="h-6 w-6 text-gaming-dark" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-white">Divisão em Destaque</h4>
                  <p className="text-gray-300">Luminous League (+1.250 troféus)</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 p-4 bg-gaming-card rounded-lg">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <Star className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-white">MVP do Mês</h4>
                  <p className="text-gray-300">ThunderStrike#BR (45 vitórias)</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 p-4 bg-gaming-card rounded-lg">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                  <Trophy className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-white">Evento Popular</h4>
                  <p className="text-gray-300">Campeonato Valyrian (156 participantes)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dashboard Statistics */}
        <DashboardStats className="mb-12" />

        {/* Active Events */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Eventos Ativos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeEvents.map((event) => {
              const statusInfo = getStatusBadge(event.status);
              const canRegister = event.status === "open" && event.currentParticipants < event.maxParticipants;
              
              return (
                <Card key={event.id} className="bg-gaming-surface border-gaming-yellow/20 hover:border-gaming-yellow/40 transition-all hover:shadow-lg hover:shadow-gaming-yellow/20">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <Badge className={statusInfo.className}>
                        {statusInfo.label}
                      </Badge>
                      <Trophy className="h-5 w-5 text-gaming-yellow" />
                    </div>
                    <CardTitle className="text-xl font-semibold text-white">{event.name}</CardTitle>
                    <p className="text-gray-300">{event.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Inscritos:</span>
                        <span className="text-white">
                          {event.currentParticipants}/{event.maxParticipants}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Data:</span>
                        <span className="text-white">
                          {event.startDate?.toDate?.()?.toLocaleDateString() || 'A definir'}
                        </span>
                      </div>
                    </div>
                    <Button
                      className={`w-full font-medium ${
                        canRegister
                          ? "bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber"
                          : "bg-gray-600 text-gray-400 cursor-not-allowed"
                      }`}
                      disabled={!canRegister}
                      onClick={() => canRegister && handleEventRegistration(event)}
                    >
                      {canRegister ? "Inscreva-se Agora" : "Inscrições Encerradas"}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>

      {/* Registration Modal */}
      {showRegistration && selectedEvent && (
        <EventRegistration
          event={selectedEvent}
          onClose={() => setShowRegistration(false)}
          onSuccess={() => {
            setShowRegistration(false);
            loadDashboardData();
          }}
        />
      )}
    </div>
  );
}
