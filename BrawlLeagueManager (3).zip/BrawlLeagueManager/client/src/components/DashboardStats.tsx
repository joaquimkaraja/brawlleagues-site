import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getDocuments } from "@/lib/firebase";
import { Trophy, Star, Users, Clock, TrendingUp } from "lucide-react";

interface Member {
  id: string;
  name: string;
  divisionId: string;
  totalFriendlies: number;
  victories: number;
}

interface Division {
  id: string;
  name: string;
  color: string;
}

interface Friendly {
  id: string;
  duration: number;
  participants: string[];
  winners: string[];
  date: any;
}

interface DashboardStatsProps {
  className?: string;
}

export function DashboardStats({ className }: DashboardStatsProps) {
  const [members, setMembers] = useState<Member[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [friendlies, setFriendlies] = useState<Friendly[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setIsLoading(true);
    try {
      const [membersData, divisionsData, friendliesData] = await Promise.all([
        getDocuments("members"),
        getDocuments("divisions"),
        getDocuments("friendlies")
      ]);

      setMembers(membersData as Member[]);
      setDivisions(divisionsData as Division[]);
      setFriendlies(friendliesData as Friendly[]);
    } catch (error) {
      console.error("Error loading stats:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getTopPlayers = () => {
    return members
      .sort((a, b) => b.victories - a.victories)
      .slice(0, 20)
      .map(member => {
        const division = divisions.find(d => d.id === member.divisionId);
        const winPercentage = member.totalFriendlies > 0 
          ? Math.round((member.victories / member.totalFriendlies) * 100)
          : 0;
        
        return {
          ...member,
          division,
          winPercentage
        };
      });
  };

  const getTotalMinutesPlayed = () => {
    return friendlies.reduce((total, friendly) => total + (friendly.duration || 0), 0);
  };

  const getAverageGrowth = () => {
    if (divisions.length === 0) return 0;
    return divisions.reduce((sum, div) => sum + ((div as any).monthlyVariation || 0), 0) / divisions.length;
  };

  const getAverageParticipation = () => {
    if (members.length === 0) return 0;
    const totalFriendlies = members.reduce((sum, member) => sum + member.totalFriendlies, 0);
    return Math.round(totalFriendlies / members.length);
  };

  const topPlayers = getTopPlayers();
  const totalMinutes = getTotalMinutesPlayed();
  const averageGrowth = getAverageGrowth();
  const averageParticipation = getAverageParticipation();

  if (isLoading) {
    return <div className="text-center text-gray-400 py-8">Carregando estatísticas...</div>;
  }

  return (
    <div className={`space-y-8 ${className}`}>
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gaming-surface border-gaming-yellow/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Total de Minutos Jogados</CardTitle>
            <Clock className="h-4 w-4 text-gaming-yellow" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gaming-yellow">
              {totalMinutes.toLocaleString()}
            </div>
            <p className="text-xs text-gray-400">
              Em {friendlies.length} amistosos registrados
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gaming-surface border-gaming-yellow/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Crescimento Médio Mensal</CardTitle>
            <TrendingUp className="h-4 w-4 text-gaming-yellow" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gaming-yellow">
              {averageGrowth > 0 ? '+' : ''}{averageGrowth.toFixed(0)}
            </div>
            <p className="text-xs text-gray-400">
              Troféus por divisão
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gaming-surface border-gaming-yellow/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Participação Média</CardTitle>
            <Users className="h-4 w-4 text-gaming-yellow" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gaming-yellow">
              {averageParticipation}
            </div>
            <p className="text-xs text-gray-400">
              Amistosos por membro
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Top 20 Players */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-white flex items-center">
            <Star className="h-5 w-5 mr-2 text-gaming-yellow" />
            Top 20 Jogadores com Mais Vitórias
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topPlayers.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum jogador com vitórias registradas
            </div>
          ) : (
            <div className="space-y-2">
              {topPlayers.map((player, index) => (
                <div
                  key={player.id}
                  className="flex items-center justify-between p-3 bg-gaming-card rounded-lg hover:bg-gaming-card/80 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                      index === 0 ? 'bg-yellow-500 text-black' :
                      index === 1 ? 'bg-gray-400 text-black' :
                      index === 2 ? 'bg-amber-600 text-black' :
                      'bg-gaming-yellow/20 text-gaming-yellow'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">{player.name}</h4>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          style={{ backgroundColor: player.division?.color }}
                          className="text-white text-xs"
                        >
                          {player.division?.name}
                        </Badge>
                        <span className="text-sm text-gray-400">
                          {player.totalFriendlies} amistosos
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-gaming-yellow">
                      {player.victories}
                    </div>
                    <div className="text-sm text-gray-400">
                      {player.winPercentage}% vitórias
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Division Performance Comparison */}
      <Card className="bg-gaming-surface border-gaming-yellow/20">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-white flex items-center">
            <Trophy className="h-5 w-5 mr-2 text-gaming-yellow" />
            Comparativo de Desempenho entre Divisões
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {divisions.map((division) => {
              const divisionMembers = members.filter(m => m.divisionId === division.id);
              const totalVictories = divisionMembers.reduce((sum, m) => sum + m.victories, 0);
              const totalFriendlies = divisionMembers.reduce((sum, m) => sum + m.totalFriendlies, 0);
              const winRate = totalFriendlies > 0 ? Math.round((totalVictories / totalFriendlies) * 100) : 0;
              
              return (
                <div key={division.id} className="p-4 bg-gaming-card rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <Badge 
                      style={{ backgroundColor: division.color }}
                      className="text-white"
                    >
                      {division.name}
                    </Badge>
                    <span className="text-gaming-yellow font-bold">{winRate}%</span>
                  </div>
                  <div className="space-y-1 text-sm text-gray-400">
                    <div>Membros: {divisionMembers.length}</div>
                    <div>Vitórias: {totalVictories}</div>
                    <div>Total de Jogos: {totalFriendlies}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}