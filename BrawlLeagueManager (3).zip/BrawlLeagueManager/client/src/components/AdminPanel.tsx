import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Users, Trophy, Clock, Plus, Check, X, History, Settings, Crown, Bell, Trash2 } from "lucide-react";
import { getDocuments, addDocument, updateDocument } from "@/lib/firebase";
import { where, orderBy, limit } from "firebase/firestore";
import { CreateEventForm } from "./forms/CreateEventForm";
import { MemberManagementForm } from "./forms/MemberManagementForm";
import { FriendlyRegistrationForm } from "./forms/FriendlyRegistrationForm";
import { TrophyUpdateForm } from "./forms/TrophyUpdateForm";
import { CreateDivisionForm } from "./forms/CreateDivisionForm";
import { AdminUserForm } from "./forms/AdminUserForm";
import { NotificationForm } from "./forms/NotificationForm";
import { MemberRemovalForm } from "./forms/MemberRemovalForm";
import { useToast } from "@/hooks/use-toast";

interface AdminUser {
  uid: string;
  displayName: string;
  role: string;
  division?: string;
}

interface AdminPanelProps {
  user: AdminUser;
  onLogout: () => void;
}

export function AdminPanel({ user, onLogout }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState("events");
  const [stats, setStats] = useState({
    activeEvents: 0,
    pendingRegistrations: 0,
    totalPlayers: 0,
    monthlyEvents: 0,
  });
  const [pendingRegistrations, setPendingRegistrations] = useState([]);
  const [actionHistory, setActionHistory] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      const [events, registrations, history] = await Promise.all([
        getDocuments("events", [where("status", "in", ["open", "active"])]),
        getDocuments("registrations", [where("status", "==", "pending")]),
        getDocuments("actionHistory", [orderBy("createdAt", "desc"), limit(20)])
      ]);

      setStats({
        activeEvents: events.length,
        pendingRegistrations: registrations.length,
        totalPlayers: 156, // This would be calculated from actual data
        monthlyEvents: 12, // This would be calculated from actual data
      });

      setPendingRegistrations(registrations);
      setActionHistory(history);
    } catch (error) {
      console.error("Error loading admin data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados administrativos",
        variant: "destructive",
      });
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    const period = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
    const levelText = user.role === "soberano" ? "Administrador Soberano" : "Alto Oficial";
    return `${period}, ${levelText}!`;
  };

  const handleRegistrationAction = async (registrationId: string, action: "approved" | "rejected") => {
    try {
      await updateDocument("registrations", registrationId, {
        status: action,
        approvedBy: user.uid,
        approvedAt: new Date(),
      });

      // Add to action history
      await addDocument("actionHistory", {
        action: action === "approved" ? "registration_approved" : "registration_rejected",
        description: `Inscrição ${action === "approved" ? "aprovada" : "rejeitada"}`,
        performedBy: user.uid,
        entityType: "registration",
        entityId: registrationId,
      });

      toast({
        title: "Sucesso",
        description: `Inscrição ${action === "approved" ? "aprovada" : "rejeitada"} com sucesso`,
      });

      loadAdminData();
    } catch (error) {
      console.error("Error handling registration:", error);
      toast({
        title: "Erro",
        description: "Erro ao processar inscrição",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gaming-dark text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Admin Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Painel Administrativo</h1>
            <p className="text-gray-400 mt-1">{getGreeting()}</p>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-400">
              Nível: {user.role === "soberano" ? "Soberano" : "Alto Oficial"}
            </span>
            <Button
              onClick={onLogout}
              variant="destructive"
              className="bg-red-600 hover:bg-red-700"
            >
              <Settings className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>

        {/* Admin Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gaming-surface border-gaming-yellow/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Eventos Ativos</p>
                  <p className="text-2xl font-bold text-gaming-yellow">{stats.activeEvents}</p>
                </div>
                <Calendar className="h-8 w-8 text-gaming-yellow" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gaming-surface border-gaming-yellow/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Inscrições Pendentes</p>
                  <p className="text-2xl font-bold text-red-400">{stats.pendingRegistrations}</p>
                </div>
                <Clock className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gaming-surface border-gaming-yellow/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Total de Jogadores</p>
                  <p className="text-2xl font-bold text-green-400">{stats.totalPlayers}</p>
                </div>
                <Users className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gaming-surface border-gaming-yellow/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Eventos Este Mês</p>
                  <p className="text-2xl font-bold text-blue-400">{stats.monthlyEvents}</p>
                </div>
                <Trophy className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Tabs */}
        <Card className="bg-gaming-surface border-gaming-yellow/20">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <CardHeader>
              <TabsList className="grid w-full grid-cols-10 bg-gaming-card text-xs">
                <TabsTrigger value="events" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Calendar className="h-3 w-3 mr-1" />
                  Eventos
                </TabsTrigger>
                <TabsTrigger value="divisions" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Crown className="h-3 w-3 mr-1" />
                  Divisões
                </TabsTrigger>
                <TabsTrigger value="members" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Users className="h-3 w-3 mr-1" />
                  Membros
                </TabsTrigger>
                <TabsTrigger value="friendlies" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Trophy className="h-3 w-3 mr-1" />
                  Amistosos
                </TabsTrigger>
                <TabsTrigger value="trophies" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Trophy className="h-3 w-3 mr-1" />
                  Troféus
                </TabsTrigger>
                <TabsTrigger value="admins" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Settings className="h-3 w-3 mr-1" />
                  Admins
                </TabsTrigger>
                <TabsTrigger value="notifications" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Bell className="h-3 w-3 mr-1" />
                  Avisos
                </TabsTrigger>
                <TabsTrigger value="remove" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Trash2 className="h-3 w-3 mr-1" />
                  Remover
                </TabsTrigger>
                <TabsTrigger value="registrations" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <Users className="h-3 w-3 mr-1" />
                  Inscrições
                </TabsTrigger>
                <TabsTrigger value="history" className="data-[state=active]:bg-gaming-yellow data-[state=active]:text-gaming-dark">
                  <History className="h-3 w-3 mr-1" />
                  Histórico
                </TabsTrigger>
              </TabsList>
            </CardHeader>

            <CardContent>
              <TabsContent value="events" className="space-y-6">
                <CreateEventForm onSuccess={loadAdminData} userRole={user.uid} />
              </TabsContent>

              <TabsContent value="divisions" className="space-y-6">
                <CreateDivisionForm onSuccess={loadAdminData} userRole={user.role} />
              </TabsContent>

              <TabsContent value="members" className="space-y-6">
                <MemberManagementForm userRole={user.role} />
              </TabsContent>

              <TabsContent value="friendlies" className="space-y-6">
                <FriendlyRegistrationForm userRole={user.uid} />
              </TabsContent>

              <TabsContent value="trophies" className="space-y-6">
                <TrophyUpdateForm userRole={user.uid} onSuccess={loadAdminData} />
              </TabsContent>

              <TabsContent value="registrations" className="space-y-4">
                <h3 className="text-xl font-semibold text-white mb-6">Inscrições Pendentes</h3>
                {pendingRegistrations.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">
                    Nenhuma inscrição pendente
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingRegistrations.map((registration: any) => (
                      <Card key={registration.id} className="bg-gaming-card border-gray-600">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <div className="w-10 h-10 bg-gaming-yellow rounded-full flex items-center justify-center">
                                <Users className="h-5 w-5 text-gaming-dark" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-white">{registration.playerName}</h4>
                                <p className="text-sm text-gray-400">
                                  {registration.playerTag && `${registration.playerTag} • `}
                                  Divisão: {registration.division}
                                </p>
                                <p className="text-xs text-gray-500">
                                  Inscrito em {registration.registeredAt?.toDate?.()?.toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => handleRegistrationAction(registration.id, "approved")}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                Aprovar
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleRegistrationAction(registration.id, "rejected")}
                              >
                                <X className="h-4 w-4 mr-1" />
                                Rejeitar
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="members" className="space-y-6">
                <MemberManagementForm userRole={user.role} />
              </TabsContent>

              <TabsContent value="friendlies" className="space-y-6">
                <FriendlyRegistrationForm userRole={user.uid} />
              </TabsContent>

              <TabsContent value="trophies" className="space-y-6">
                <TrophyUpdateForm userRole={user.uid} onSuccess={loadAdminData} />
              </TabsContent>

              <TabsContent value="brackets" className="space-y-6">
                <h3 className="text-xl font-semibold text-white mb-6">
                  Chaveamento Atual - Campeonato Luminous
                </h3>
                <div className="bg-gaming-card rounded-lg p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="space-y-4">
                      <h4 className="text-center font-semibold text-gaming-yellow mb-4">
                        Quartas de Final
                      </h4>
                      <div className="space-y-3">
                        {[
                          ["Team Lightning", "Team Thunder"],
                          ["Team Storm", "Team Blaze"],
                          ["Team Shadow", "Team Frost"],
                          ["Team Phoenix", "Team Viper"],
                        ].map(([team1, team2], index) => (
                          <Card key={index} className="bg-gaming-surface border-l-4 border-gaming-yellow">
                            <CardContent className="p-3">
                              <div className="text-sm text-white font-medium">{team1}</div>
                              <div className="text-xs text-gray-400 text-center">vs</div>
                              <div className="text-sm text-white font-medium">{team2}</div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-center font-semibold text-gaming-yellow mb-4">
                        Semifinais
                      </h4>
                      <div className="space-y-6">
                        <Card className="bg-gaming-surface border-l-4 border-green-500">
                          <CardContent className="p-3">
                            <div className="text-sm text-white font-medium">Team Lightning</div>
                            <div className="text-xs text-gray-400 text-center">vs</div>
                            <div className="text-sm text-gray-500">Aguardando</div>
                          </CardContent>
                        </Card>
                        <Card className="bg-gaming-surface border-l-4 border-gray-500">
                          <CardContent className="p-3">
                            <div className="text-sm text-gray-500">Aguardando</div>
                            <div className="text-xs text-gray-400 text-center">vs</div>
                            <div className="text-sm text-gray-500">Aguardando</div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-center font-semibold text-gaming-yellow mb-4">Final</h4>
                      <Card className="bg-gaming-surface border-l-4 border-gray-500">
                        <CardContent className="p-4">
                          <div className="text-center">
                            <div className="text-sm text-gray-500 mb-2">Aguardando</div>
                            <div className="text-xs text-gray-400">vs</div>
                            <div className="text-sm text-gray-500 mt-2">Aguardando</div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                <h3 className="text-xl font-semibold text-white mb-6">
                  Histórico de Ações (Últimas 20)
                </h3>
                {actionHistory.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">
                    Nenhuma ação registrada
                  </div>
                ) : (
                  <div className="space-y-3">
                    {actionHistory.map((action: any) => (
                      <Card key={action.id} className="bg-gaming-card border-gray-600">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-4">
                            <div className="w-8 h-8 bg-gaming-yellow rounded-full flex items-center justify-center flex-shrink-0">
                              <Plus className="h-4 w-4 text-gaming-dark" />
                            </div>
                            <div className="flex-1">
                              <p className="text-white text-sm">{action.description}</p>
                              <p className="text-gray-400 text-xs">
                                Por: {action.performedBy} • {action.createdAt?.toDate?.()?.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}
