import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { loginWithCredentials, PREDEFINED_USERS } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const loginSchema = z.object({
  username: z.string().min(1, "Username é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória"),
});

type LoginForm = z.infer<typeof loginSchema>;

interface LoginModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (user: any) => void;
}

export function LoginModal({ open, onClose, onSuccess }: LoginModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginForm) => {
    setIsLoading(true);
    try {
      // Check if user exists in predefined users
      const predefinedUser = PREDEFINED_USERS[data.username as keyof typeof PREDEFINED_USERS];
      
      if (!predefinedUser || predefinedUser.password !== data.password) {
        toast({
          title: "Erro",
          description: "Credenciais inválidas",
          variant: "destructive",
        });
        return;
      }

      // For demonstration, we'll simulate Firebase auth
      // In production, you would use Firebase Auth with email/password
      const mockUser = {
        uid: data.username,
        email: `${data.username}@brawlleagues.com`,
        displayName: predefinedUser.displayName,
        role: predefinedUser.role,
        division: predefinedUser.division,
      };

      toast({
        title: "Sucesso!",
        description: "Login realizado com sucesso!",
      });

      onSuccess(mockUser);
      onClose();
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Erro",
        description: "Erro ao fazer login. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gaming-surface border-gaming-yellow/20 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gaming-yellow text-center">
            Login Administrativo
          </DialogTitle>
          <p className="text-gray-400 text-center">Acesso restrito para administradores</p>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Usuário</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="Digite seu usuário"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Senha</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="password"
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="Digite sua senha"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex space-x-3 pt-4">
              <Button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="flex-1 bg-gaming-yellow hover:bg-gaming-amber text-gaming-dark font-medium"
              >
                {isLoading ? "Entrando..." : "Entrar"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
