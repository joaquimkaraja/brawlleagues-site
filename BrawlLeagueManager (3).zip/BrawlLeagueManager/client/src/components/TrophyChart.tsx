import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getDocuments } from "@/lib/firebase";

interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    borderColor: string;
    backgroundColor: string;
    tension: number;
  }[];
}

export function TrophyChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);
  const [timeRange, setTimeRange] = useState("1month");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadChart();
  }, [timeRange]);

  const loadChart = async () => {
    setIsLoading(true);
    try {
      // Load Chart.js dynamically
      const Chart = await import('chart.js/auto');
      
      if (chartRef.current) {
        chartRef.current.destroy();
      }

      const ctx = canvasRef.current?.getContext('2d');
      if (!ctx) return;

      // Mock data for demonstration - in real app, this would come from Firebase
      const chartData: ChartData = {
        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
        datasets: [
          {
            label: 'Luminous League',
            data: [23600, 23800, 24200, 24000, 24400, 24850],
            borderColor: '#FDB813',
            backgroundColor: 'rgba(253, 184, 19, 0.1)',
            tension: 0.4
          },
          {
            label: 'Valyrian League',
            data: [21500, 21800, 22100, 21900, 22200, 22340],
            borderColor: '#EF4444',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            tension: 0.4
          },
          {
            label: 'Shadow League',
            data: [20100, 20200, 19800, 19900, 20050, 19720],
            borderColor: '#FDB813',
            backgroundColor: 'rgba(253, 184, 19, 0.1)',
            tension: 0.4
          },
          {
            label: 'Storm League',
            data: [20800, 21000, 21200, 21100, 21400, 21560],
            borderColor: '#F59E0B',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            tension: 0.4
          }
        ]
      };

      chartRef.current = new Chart.default(ctx, {
        type: 'line',
        data: chartData,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: {
                color: '#ffffff'
              }
            }
          },
          scales: {
            x: {
              ticks: {
                color: '#9CA3AF'
              },
              grid: {
                color: 'rgba(156, 163, 175, 0.1)'
              }
            },
            y: {
              ticks: {
                color: '#9CA3AF'
              },
              grid: {
                color: 'rgba(156, 163, 175, 0.1)'
              }
            }
          }
        }
      });
    } catch (error) {
      console.error("Error loading chart:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-gaming-surface border-gaming-yellow/20">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl font-semibold text-white">Progressão de Troféus</CardTitle>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-40 bg-gaming-card border-gray-600 text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gaming-card border-gray-600">
            <SelectItem value="1month">Último mês</SelectItem>
            <SelectItem value="3months">3 meses</SelectItem>
            <SelectItem value="6months">6 meses</SelectItem>
            <SelectItem value="12months">12 meses</SelectItem>
            <SelectItem value="all">Todo o período</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="h-64 relative">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-gray-400">Carregando gráfico...</div>
            </div>
          ) : (
            <canvas ref={canvasRef} />
          )}
        </div>
      </CardContent>
    </Card>
  );
}
