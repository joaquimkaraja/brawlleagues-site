import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { addDocument, getDocuments } from "@/lib/firebase";
import { where } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const registrationSchema = z.object({
  playerName: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  playerTag: z.string().optional(),
  division: z.string().min(1, "Selecione uma divisão"),
  acceptRules: z.boolean().refine(val => val === true, "Você deve aceitar as regras"),
});

type RegistrationForm = z.infer<typeof registrationSchema>;

interface Event {
  id: string;
  name: string;
  description: string;
  type: string;
  maxParticipants: number;
  currentParticipants: number;
}

interface EventRegistrationProps {
  event: Event;
  onClose: () => void;
  onSuccess: () => void;
}

export function EventRegistration({ event, onClose, onSuccess }: EventRegistrationProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<RegistrationForm>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      playerName: "",
      playerTag: "",
      division: "",
      acceptRules: false,
    },
  });

  const onSubmit = async (data: RegistrationForm) => {
    setIsSubmitting(true);
    try {
      // Check for duplicate registration
      const existingRegistrations = await getDocuments("registrations", [
        where("eventId", "==", event.id),
        where("playerName", "==", data.playerName),
      ]);

      if (existingRegistrations.length > 0) {
        toast({
          title: "Erro",
          description: "Você já está inscrito neste evento",
          variant: "destructive",
        });
        return;
      }

      // Add registration
      await addDocument("registrations", {
        eventId: event.id,
        playerName: data.playerName,
        playerTag: data.playerTag || "",
        division: data.division,
        status: "pending",
      });

      // Add notification for admins
      await addDocument("notifications", {
        title: "Nova Inscrição",
        message: `${data.playerName} se inscreveu no evento ${event.name}`,
        type: "info",
        priority: "medium",
      });

      toast({
        title: "Sucesso!",
        description: "Inscrição enviada! Aguarde aprovação do administrador.",
      });

      onSuccess();
    } catch (error) {
      console.error("Error submitting registration:", error);
      toast({
        title: "Erro",
        description: "Erro ao enviar inscrição. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-gaming-surface border-gaming-yellow/20 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gaming-yellow text-center">
            Inscrição no Evento
          </DialogTitle>
          <p className="text-gray-400 text-center">{event.name}</p>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="playerName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Nome do Jogador *</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="Digite seu nome"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="playerTag"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Tag do Brawl Stars</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow"
                      placeholder="#ABC123 (opcional)"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="division"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-300">Divisão *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-gaming-card border-gray-600 text-white focus:border-gaming-yellow">
                        <SelectValue placeholder="Selecione sua divisão" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-gaming-card border-gray-600">
                      <SelectItem value="luminous">Luminous League</SelectItem>
                      <SelectItem value="valyrian">Valyrian League</SelectItem>
                      <SelectItem value="shadow">Shadow League</SelectItem>
                      <SelectItem value="storm">Storm League</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="acceptRules"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      className="border-gray-600 data-[state=checked]:bg-gaming-yellow data-[state=checked]:border-gaming-yellow"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm text-gray-300">
                      Concordo com as regras do evento e declaro que as informações fornecidas são verdadeiras.
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />

            <div className="flex space-x-3 pt-4">
              <Button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 bg-gaming-yellow hover:bg-gaming-amber text-gaming-dark font-medium"
              >
                {isSubmitting ? "Enviando..." : "Inscrever-se"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
