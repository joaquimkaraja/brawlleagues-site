import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bell, AlertTriangle, Info, Trophy, X } from "lucide-react";
import { getDocuments, updateDocument } from "@/lib/firebase";
import { orderBy, limit } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  priority: "low" | "medium" | "high";
  isRead: boolean;
  createdAt: any;
}

interface NotificationDropdownProps {
  open: boolean;
  onClose: () => void;
}

const typeIcons = {
  info: Info,
  warning: AlertTriangle,
  error: AlertTriangle,
  success: Trophy,
};

const typeColors = {
  info: "text-blue-500",
  warning: "text-yellow-500",
  error: "text-red-500",
  success: "text-gaming-yellow",
};

export function NotificationDropdown({ open, onClose }: NotificationDropdownProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      loadNotifications();
    }
  }, [open]);

  const loadNotifications = async () => {
    setIsLoading(true);
    try {
      const notificationsData = await getDocuments("notifications", [
        orderBy("createdAt", "desc"),
        limit(10)
      ]);
      setNotifications(notificationsData as Notification[]);
    } catch (error) {
      console.error("Error loading notifications:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar notificações",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      await updateDocument("notifications", notificationId, { isRead: true });
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
      );
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  const getTimeAgo = (timestamp: any) => {
    if (!timestamp) return "Agora";
    
    const now = new Date();
    const notificationTime = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - notificationTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Agora";
    if (diffInMinutes < 60) return `${diffInMinutes} min atrás`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} h atrás`;
    return `${Math.floor(diffInMinutes / 1440)} dias atrás`;
  };

  if (!open) return null;

  return (
    <div className="fixed top-16 right-4 w-80 z-50">
      <Card className="bg-gaming-surface border-gaming-yellow/20 shadow-xl">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-lg font-semibold text-gaming-yellow">
            Notificações
          </CardTitle>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </CardHeader>
        <CardContent className="max-h-96 overflow-y-auto">
          {isLoading ? (
            <div className="text-center text-gray-400 py-4">
              Carregando notificações...
            </div>
          ) : notifications.length === 0 ? (
            <div className="text-center text-gray-400 py-4">
              Nenhuma notificação
            </div>
          ) : (
            <div className="space-y-3">
              {notifications.map((notification) => {
                const IconComponent = typeIcons[notification.type];
                const iconColor = typeColors[notification.type];
                
                return (
                  <div
                    key={notification.id}
                    className={`flex items-start space-x-3 p-3 rounded-lg cursor-pointer transition-colors ${
                      notification.isRead ? 'bg-gaming-card/50' : 'bg-gaming-card'
                    } hover:bg-gaming-card/80`}
                    onClick={() => !notification.isRead && markAsRead(notification.id)}
                  >
                    <div className="flex-shrink-0 mt-1">
                      <IconComponent className={`h-4 w-4 ${iconColor}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className={`text-sm font-medium ${notification.isRead ? 'text-gray-400' : 'text-white'}`}>
                          {notification.title}
                        </p>
                        {!notification.isRead && (
                          <div className="w-2 h-2 bg-gaming-yellow rounded-full flex-shrink-0" />
                        )}
                      </div>
                      <p className={`text-sm ${notification.isRead ? 'text-gray-500' : 'text-gray-300'}`}>
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {getTimeAgo(notification.createdAt)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
