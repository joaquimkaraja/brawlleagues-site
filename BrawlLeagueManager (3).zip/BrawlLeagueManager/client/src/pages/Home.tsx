import { useState, useEffect } from "react";
import { Dashboard } from "@/components/Dashboard";
import { AdminPanel } from "@/components/AdminPanel";
import { LoginModal } from "@/components/LoginModal";
import { NotificationDropdown } from "@/components/NotificationDropdown";
import { Button } from "@/components/ui/button";
import { Bell, Trophy, Users, TrendingUp, Instagram, MessageCircle } from "lucide-react";
import { FaTiktok, FaDiscord } from "react-icons/fa";
import { getDocuments } from "@/lib/firebase";
import { where } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";

interface User {
  uid: string;
  displayName: string;
  role: string;
  division?: string;
}

export default function Home() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    loadNotificationCount();
  }, []);

  const loadNotificationCount = async () => {
    try {
      const notifications = await getDocuments("notifications", [
        where("isRead", "==", false)
      ]);
      setNotificationCount(notifications.length);
    } catch (error) {
      console.error("Error loading notification count:", error);
    }
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    toast({
      title: "Bem-vindo!",
      description: `Login realizado com sucesso, ${user.displayName}!`,
    });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    toast({
      title: "Logout",
      description: "Logout realizado com sucesso!",
    });
  };

  const isAdmin = currentUser && (currentUser.role === "soberano" || currentUser.role === "oficial");

  return (
    <div className="min-h-screen bg-gaming-dark">
      {/* Navigation Header */}
      <nav className="bg-gaming-surface shadow-lg border-b border-gaming-yellow/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-gaming-yellow flex items-center">
                  <Trophy className="h-6 w-6 mr-2" />
                  Brawl Leagues
                </h1>
              </div>
              <div className="hidden md:block">
                <div className="ml-10 flex items-baseline space-x-4">
                  <button
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      !isAdmin ? 'text-gaming-yellow' : 'text-gray-300 hover:text-gaming-yellow'
                    }`}
                    onClick={() => !isAdmin && setCurrentUser(null)}
                  >
                    Sistema de Gerenciamento
                  </button>
                  <button className="text-gray-300 hover:text-gaming-yellow px-3 py-2 rounded-md text-sm font-medium transition-colors">
                    Eventos
                  </button>
                  <button className="text-gray-300 hover:text-gaming-yellow px-3 py-2 rounded-md text-sm font-medium transition-colors">
                    Rankings
                  </button>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {/* Notification Bell */}
              <button
                className="relative p-2 text-gray-300 hover:text-gaming-yellow transition-colors"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="h-5 w-5" />
                {notificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {notificationCount}
                  </span>
                )}
              </button>

              {/* Login/Admin Button */}
              {currentUser ? (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-300">
                    Olá, {currentUser.displayName}
                  </span>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    className="border-gaming-yellow text-gaming-yellow hover:bg-gaming-yellow hover:text-gaming-dark"
                  >
                    Sair
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={() => setShowLoginModal(true)}
                  className="bg-gaming-yellow text-gaming-dark hover:bg-gaming-amber font-medium"
                >
                  <Users className="h-4 w-4 mr-2" />
                  Login Admin
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Notification Dropdown */}
      <NotificationDropdown
        open={showNotifications}
        onClose={() => setShowNotifications(false)}
      />

      {/* Main Content */}
      {isAdmin ? (
        <AdminPanel user={currentUser} onLogout={handleLogout} />
      ) : (
        <Dashboard />
      )}

      {/* Footer */}
      <footer className="bg-gaming-surface border-t border-gaming-yellow/20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold text-gaming-yellow mb-4 flex items-center">
                <Trophy className="h-5 w-5 mr-2" />
                Brawl Leagues
              </h3>
              <p className="text-gray-400 mb-4">
                Sistema de gerenciamento para a maior comunidade competitiva de Brawl Stars do Brasil. Conectando jogadores e criando lendas.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Divisões Ativas</h4>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <Trophy className="h-4 w-4 text-gaming-yellow mr-2" />
                  Luminous League
                </li>
                <li className="flex items-center">
                  <Trophy className="h-4 w-4 text-red-500 mr-2" />
                  Valyrian League
                </li>
                <li className="flex items-center">
                  <Trophy className="h-4 w-4 text-purple-500 mr-2" />
                  Shadow League
                </li>
                <li className="flex items-center">
                  <Trophy className="h-4 w-4 text-blue-500 mr-2" />
                  Storm League
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Redes Sociais</h4>
              <div className="flex space-x-4">
                <a
                  href="https://discord.gg/6aQfmBwWXx"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-[#5865F2] rounded-lg flex items-center justify-center hover:bg-opacity-80 transition-colors"
                >
                  <FaDiscord className="text-white" />
                </a>
                <a
                  href="https://instagram.com/brawlleaguesbr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center hover:bg-opacity-80 transition-colors"
                >
                  <Instagram className="h-5 w-5 text-white" />
                </a>
                <a
                  href="https://tiktok.com/@brawl.leagues"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-black rounded-lg flex items-center justify-center hover:bg-gray-800 transition-colors"
                >
                  <FaTiktok className="text-white" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-600 mt-8 pt-6 text-center">
            <p className="text-gray-400">© 2025 Brawl Leagues - Todos os direitos reservados</p>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      <LoginModal
        open={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSuccess={handleLogin}
      />
    </div>
  );
}
