# Brawl Leagues - Sistema de Gerenciamento

Sistema de gerenciamento para a comunidade Brawl Leagues, com dashboard público, painel administrativo e sistema de eventos.

## 🚀 Recursos Principais

- **Dashboard Público**: Visualização de estatísticas das 4 divisões ativas
- **Painel Administrativo**: Controle completo para administradores (2 níveis de acesso)
- **Sistema de Eventos**: 6 tipos de eventos pré-configurados
- **Inscrições Públicas**: Sistema de registro para eventos com aprovação administrativa
- **Integração Firebase**: Banco de dados em tempo real e autenticação

## 🏆 Divisões Ativas

1. **Luminous League** - Divisão Elite
2. **Valyrian League** - Divisão Avançada  
3. **Shadow League** - Divisão Intermediária
4. **Storm League** - Divisão Iniciante

## 🛠️ Stack Tecnológica

- **Frontend**: React 18 + TypeScript + TailwindCSS
- **Backend**: Node.js + Express + TypeScript
- **Database**: Firebase Firestore
- **Authentication**: Firebase Auth
- **Hospedagem**: GitHub Pages compatível
- **Gráficos**: Chart.js
- **UI Components**: Radix UI + shadcn/ui

## 📋 Pré-requisitos

- Node.js 18+
- Conta Firebase
- Git

## ⚙️ Configuração do Projeto

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/brawlleagues.git
cd brawlleagues
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Configuração do Firebase

#### 3.1 Criar projeto no Firebase
1. Acesse [Firebase Console](https://console.firebase.google.com/)
2. Clique em "Criar projeto" ou use o projeto existente: `brawlleagues`
3. Ative o Firestore Database
4. Configure Authentication com método Email/Password

#### 3.2 Configurar variáveis de ambiente
Crie um arquivo `.env` na raiz do projeto:

```env
VITE_FIREBASE_API_KEY=sua_api_key_aqui
VITE_FIREBASE_APP_ID=1:1016284202866:web:423e5d9218731737343feb
VITE_FIREBASE_PROJECT_ID=brawlleagues
```

**Configuração Firebase atual:**
- **Project ID**: `brawlleagues`
- **App ID**: `1:1016284202866:web:423e5d9218731737343feb`
- **Messaging Sender ID**: `1016284202866`

### 4. Executar o projeto
```bash
# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Servir build de produção
npm start
```

## 👑 Sistema de Usuários Pré-configurados

### Administrador Soberano
- **Usuário**: `joaquim.admin`
- **Senha**: `S0b@2025`
- **Acesso**: Controle total do sistema

### Altos Oficiais por Divisão

#### Luminous League
- **Danielle**: `danielle.luminous` | Senha: `L1gHt@2025`
- **João**: `joao.luminous` | Senha: `J0l!2025`

#### Valyrian League
- **João Vinícius**: `joaovinicius.valyrian` | Senha: `ValyR@2025`
- **Kael**: `kael.valyrian` | Senha: `KaeL@2025`

## 🎮 Tipos de Eventos

1. **Campeonato por Etapas** - Eliminação única com chaveamento
2. **Evento de Combate** - Solo ou Duo com critérios de pontuação
3. **Maratona de Troféus** - Ranking por maior crescimento
4. **Ranking Geral** - Múltiplas métricas combinadas
5. **Evento Flash** - Duração curta (2-6 horas)
6. **Caça ao MVP** - Sistema de medalhas virtuais

## 📊 Dashboard Público

### Recursos Disponíveis
- **Cards das Divisões**: Troféus atuais, variação mensal, jogadores ativos
- **Gráficos Interativos**: Progressão de troféus com filtros temporais
  - Último mês
  - 3 meses
  - 6 meses
  - 12 meses
  - Todo o período
- **Destaques do Mês**: Divisão, jogador e evento em destaque
- **Eventos Ativos**: Lista com possibilidade de inscrição

## 🔐 Painel Administrativo

### Funcionalidades Exclusivas
- **Gestão de Eventos**: Criação e configuração completa
- **Aprovação de Inscrições**: Sistema de aprovação manual
- **Chaveamentos**: Visualização de brackets de torneios
- **Histórico de Ações**: Log das últimas 20 ações administrativas
- **Notificações**: Sistema interno com níveis de prioridade

## 🌐 Deployment para GitHub Pages

### 1. Configurar GitHub Pages
1. Vá para Settings > Pages no seu repositório
2. Selecione source: "GitHub Actions"
3. Use o workflow fornecido em `.github/workflows/deploy.yml`

### 2. Configurar Secrets do GitHub
No GitHub, vá para Settings > Secrets and Variables > Actions e adicione:

```
VITE_FIREBASE_API_KEY=sua_api_key
VITE_FIREBASE_APP_ID=1:1016284202866:web:423e5d9218731737343feb
VITE_FIREBASE_PROJECT_ID=brawlleagues
```

### 3. Workflow de Deploy
O projeto está configurado para deploy automático através do GitHub Actions.

## 📱 Redes Sociais

- **Discord**: [discord.gg/6aQfmBwWXx](https://discord.gg/6aQfmBwWXx)
- **Instagram**: [@brawlleaguesbr](https://instagram.com/brawlleaguesbr)
- **TikTok**: [@brawl.leagues](https://tiktok.com/@brawl.leagues)

## 🔧 Comandos Úteis

```bash
# Verificar erros
npm run type-check

# Limpar cache
npm run clean

# Atualizar dependências
npm update

# Audit de segurança
npm audit fix
```

## 📄 Licença

© 2025 Brawl Leagues - Todos os direitos reservados

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📞 Suporte

Para suporte técnico ou dúvidas sobre o sistema, entre em contato através do Discord oficial da comunidade.

---

**Desenvolvido para a comunidade Brawl Leagues** ⚡