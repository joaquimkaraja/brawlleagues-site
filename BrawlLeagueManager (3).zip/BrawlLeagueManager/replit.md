# Brawl Leagues Manager - System Architecture

## Overview

Brawl Leagues Manager is a community management system for the Brawl Leagues gaming community. The application provides a public dashboard for viewing league statistics and an administrative panel with role-based access control for managing events and registrations. The system is designed as a full-stack web application with modern React frontend and Express.js backend, utilizing PostgreSQL for data persistence.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: TailwindCSS with custom gaming-themed color palette
- **State Management**: TanStack Query for server state, React hooks for local state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite with custom configuration for multi-environment support

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: In-memory storage with extensible interface
- **Development**: Hot reload with Vite integration

### Data Layer
- **ORM**: Drizzle with TypeScript-first approach
- **Schema**: Centralized in shared directory for type safety
- **Migrations**: Drizzle Kit for database schema management
- **Connection**: Serverless-optimized connection pooling

## Key Components

### Database Schema
- **Users Table**: Authentication and role management (soberano, oficial, user)
- **Divisions Table**: League divisions with trophy tracking and player counts
- **Events Table**: Event management with multiple types and status tracking
- **Registrations Table**: Player registrations for events with approval workflow

### Authentication System
- **Role-based Access**: Three-tier system (soberano, oficial, user)
- **Division Assignment**: Users can be assigned to specific divisions
- **Session Management**: Extensible storage interface supporting different backends

### Event Management
- **Event Types**: Tournament, combat, marathon, ranking, flash, MVP
- **Status Workflow**: Draft → Open → Active → Completed/Cancelled
- **Configuration**: JSON-based flexible event configuration
- **Registration System**: Public registration with administrative approval

### UI Components
- **Dashboard**: Public-facing statistics and league information
- **Admin Panel**: Role-restricted administrative interface
- **Event Registration**: Public forms for event participation
- **Notification System**: Toast notifications for user feedback

## Data Flow

### Public Dashboard Flow
1. Client requests division statistics and active events
2. Server queries database for current league standings
3. Data is formatted and cached for optimal performance
4. Client renders interactive charts and event listings

### Administrative Flow
1. Admin authenticates through login modal
2. Role verification determines accessible features
3. Admin actions (create/update events) trigger database operations
4. Changes propagate to public dashboard in real-time
5. Action history is logged for audit purposes

### Event Registration Flow
1. Public user fills registration form
2. Client validates form data using Zod schemas
3. Registration is submitted with pending status
4. Admin reviews and approves/rejects registrations
5. Status updates notify registrants through notifications

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management and caching
- **@hookform/resolvers**: Form validation integration
- **wouter**: Lightweight React routing

### UI Dependencies
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling

## Deployment Strategy

### Development Environment
- **Command**: `npm run dev`
- **Process**: TSX directly executes TypeScript server code
- **Vite Integration**: Middleware mode for seamless frontend/backend development
- **Hot Reload**: Both client and server code reload on changes

### Production Build
- **Frontend**: Vite builds React application to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`
- **Command**: `npm run build && npm start`
- **Optimization**: Tree shaking, code splitting, and asset optimization

### Deployment Configuration
- **Platform**: Replit with autoscale deployment
- **Port Configuration**: Server runs on port 5000, externally mapped to port 80
- **Environment**: PostgreSQL 16 module with automatic provisioning
- **Build Process**: Automated build and deployment pipeline

### Database Management
- **Schema Push**: `npm run db:push` for development schema updates
- **Migrations**: Generated in `./migrations` directory
- **Connection**: Environment variable `DATABASE_URL` required

## Recent Changes

- June 24, 2025: Initial setup completed
- June 24, 2025: Updated theme from purple to yellow throughout the application
- June 24, 2025: Updated title to "Sistema de gerenciamento" and removed "Manager" 
- June 24, 2025: Configured to display only 4 active divisions
- June 24, 2025: Added "Todo o período" filter option to trophy progression chart
- June 24, 2025: Configured Firebase integration with provided credentials
- June 24, 2025: Created GitHub deployment workflow and documentation
- June 24, 2025: Fixed friendly registration to support multiple winners instead of single winner
- June 24, 2025: Removed 180-minute time limit from friendly duration
- June 24, 2025: Added team/individual registration options for events
- June 24, 2025: Updated dashboard to use real Firebase data instead of mock data
- June 24, 2025: Added admin list visibility for Soberano level users
- June 24, 2025: Created notification/announcement creation form
- June 24, 2025: Added member removal functionality for Soberano/High Official levels
- June 24, 2025: Updated trophy progression chart to use user-created divisions

## User Preferences

Preferred communication style: Simple, everyday language.