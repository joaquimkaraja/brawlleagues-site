import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // 'soberano', 'oficial', 'user'
  division: text("division"), // 'luminous', 'valyrian', 'shadow', 'storm'
  displayName: text("display_name"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const divisions = pgTable("divisions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  currentTrophies: integer("current_trophies").notNull().default(0),
  monthlyVariation: integer("monthly_variation").notNull().default(0),
  activePlayers: integer("active_players").notNull().default(0),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // 'tournament', 'combat', 'marathon', 'ranking', 'flash', 'mvp'
  status: text("status").notNull().default("draft"), // 'draft', 'open', 'active', 'completed', 'cancelled'
  maxParticipants: integer("max_participants"),
  currentParticipants: integer("current_participants").default(0),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  configuration: jsonb("configuration"), // Event-specific config
  isPublicVisible: boolean("is_public_visible").default(false),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const registrations = pgTable("registrations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  playerName: text("player_name").notNull(),
  playerTag: text("player_tag"),
  division: text("division").notNull(),
  status: text("status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  registeredAt: timestamp("registered_at").defaultNow(),
  approvedBy: integer("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"), // 'info', 'warning', 'error', 'success'
  priority: text("priority").notNull().default("low"), // 'low', 'medium', 'high'
  isRead: boolean("is_read").default(false),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const actionHistory = pgTable("action_history", {
  id: serial("id").primaryKey(),
  action: text("action").notNull(),
  description: text("description").notNull(),
  performedBy: integer("performed_by").references(() => users.id).notNull(),
  entityType: text("entity_type"), // 'event', 'registration', 'user', etc.
  entityId: integer("entity_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trophyHistory = pgTable("trophy_history", {
  id: serial("id").primaryKey(),
  divisionId: integer("division_id").references(() => divisions.id).notNull(),
  trophies: integer("trophies").notNull(),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  divisionId: integer("division_id").references(() => divisions.id).notNull(),
  totalFriendlies: integer("total_friendlies").default(0),
  victories: integer("victories").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const friendlies = pgTable("friendlies", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  duration: integer("duration_minutes").notNull(),
  divisions: text("divisions").array().notNull(),
  participants: text("participants").array().notNull(),
  winners: text("winners").array().notNull(),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const eventParticipants = pgTable("event_participants", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  participantName: text("participant_name").notNull(),
  score: integer("score").default(0),
  trophies: integer("trophies").default(0),
  position: integer("position"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertDivisionSchema = createInsertSchema(divisions).omit({ id: true, updatedAt: true });
export const insertEventSchema = createInsertSchema(events).omit({ id: true, createdAt: true, updatedAt: true });
export const insertRegistrationSchema = createInsertSchema(registrations).omit({ id: true, registeredAt: true, approvedAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export const insertActionHistorySchema = createInsertSchema(actionHistory).omit({ id: true, createdAt: true });
export const insertTrophyHistorySchema = createInsertSchema(trophyHistory).omit({ id: true, recordedAt: true });
export const insertMemberSchema = createInsertSchema(members).omit({ id: true, createdAt: true });
export const insertFriendlySchema = createInsertSchema(friendlies).omit({ id: true, createdAt: true });
export const insertEventParticipantSchema = createInsertSchema(eventParticipants).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Division = typeof divisions.$inferSelect;
export type InsertDivision = z.infer<typeof insertDivisionSchema>;
export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Registration = typeof registrations.$inferSelect;
export type InsertRegistration = z.infer<typeof insertRegistrationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type ActionHistory = typeof actionHistory.$inferSelect;
export type InsertActionHistory = z.infer<typeof insertActionHistorySchema>;
export type TrophyHistory = typeof trophyHistory.$inferSelect;
export type InsertTrophyHistory = z.infer<typeof insertTrophyHistorySchema>;
export type Member = typeof members.$inferSelect;
export type InsertMember = z.infer<typeof insertMemberSchema>;
export type Friendly = typeof friendlies.$inferSelect;
export type InsertFriendly = z.infer<typeof insertFriendlySchema>;
export type EventParticipant = typeof eventParticipants.$inferSelect;
export type InsertEventParticipant = z.infer<typeof insertEventParticipantSchema>;
